"""Compact selected-image evidence packet, not a runnable/full-frame archive."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path.cwd()
base = root / "build/diagnostics/collection-layout"
entries = {}
for name, prefix in (("collection-before-v1", "before"), ("collection-after-v2", "after")):
    capture = base / name
    entries[prefix + "/manifest.json"] = capture / "manifest.json"
    for path in sorted((capture / "source").rglob("*")):
        if path.is_file():
            entries[prefix + "/source/" + path.relative_to(capture / "source").as_posix()] = path
    for size in ("1280x720", "960x540", "1920x1080", "2560x1080"):
        filename = size + "-collection-settled.png"
        entries[prefix + "/" + filename] = capture / filename
compat = root / "build/diagnostics/combat-status/status-collection-compat-v1"
entries["compat/manifest.json"] = compat / "manifest.json"
for path in sorted((compat / "source").rglob("*")):
    if path.is_file():
        entries["compat/source/" + path.relative_to(compat / "source").as_posix()] = path
for name in ("collection-red-v1.log", "layout-final-v1.log", "full-gate-collection-v2.log", "collection-before-v1.log", "collection-after-v2.log", "status-compat-v1.log", "before-external-v1.json", "after-external-v2.json", "compat-external-v1.json", "check_collection_evidence.py", "pack_collection_evidence.py"):
    entries["diagnostics/" + name] = base / name
entries["diagnostics/check_status_evidence.py"] = root / "build/diagnostics/combat-status/check_status_evidence.py"
for name in ("VerifyCollectionStatusLayout", "VerifyCombatStatusLayout"):
    entries["source/" + name + ".gd.uid"] = root / "scripts/art" / (name + ".gd.uid")
archive = root / "docs/collection-status-layout-evidence-v1.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for relative, path in entries.items():
        bundle.write(path, relative)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(entries)
    for relative, path in entries.items():
        assert bundle.read(relative) == path.read_bytes(), relative
assert archive.stat().st_size < 15_000_000
print(json.dumps({"entries": len(entries), "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "entry_bytes_verified": True, "selected_capture_png": 8, "scope": "selected 8 of 64 before/after images; manifests/frozen sources/logs; all unbundled PNG remain local; not runnable or full 96-image verification archive"}))
