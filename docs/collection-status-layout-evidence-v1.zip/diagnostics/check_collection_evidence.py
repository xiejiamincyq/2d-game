"""Readonly selected-source/native component evidence, not gameplay acceptance."""
import hashlib
import itertools
import json
import math
import sys
from pathlib import Path
from PIL import Image

project = Path(__file__).resolve().parents[3]
capture = Path(sys.argv[1]).resolve()
after = sys.argv[2] == "after"
manifest = json.loads((capture / "manifest.json").read_text(encoding="utf-8"))
errors, overlaps = [], []
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sizes = ((1280, 720), (960, 540), (1920, 1080), (2560, 1080))
modes = ("collection", "collection_overdrive", "boss_all_collection", "collection_fade")
timings = ("first_draw", "settled")
records = manifest["images"]
keys = [(tuple(r["viewport"]), r["mode"], r["timing"]) for r in records]
assert manifest["valid"] is True and len(keys) == len(set(keys)) == 32
assert set(keys) == set(itertools.product(sizes, modes, timings))
assert len(manifest["source_sha256"]) == 13
for relative, digest in manifest["source_sha256"].items():
    frozen = (capture / "source" / relative).resolve()
    assert frozen.is_relative_to(capture / "source") and sha(frozen) == digest, relative
    if after:
        assert sha(project / relative) == digest, relative

def rect_valid(rect):
    return len(rect) == 4 and all(math.isfinite(v) for v in rect) and min(rect[2:]) > 0

def area(a, b):
    return max(0, min(a[0]+a[2], b[0]+b[2])-max(a[0], b[0])) * max(0, min(a[1]+a[3], b[1]+b[3])-max(a[1], b[1]))

for r in records:
    path = (capture / r["file"]).resolve()
    assert path.parent == capture and sha(path) == r["sha256"], r["file"]
    with Image.open(path) as bitmap:
        assert list(bitmap.size) == r["viewport"]
        assert len(set(bitmap.convert("L").getextrema())) == 2
    width, height = r["viewport"]
    for panel in r["panels"]:
        x, y, w, h = panel["rect"]
        assert rect_valid(panel["rect"]) and min(x, y) >= 0 and x+w <= width+0.01 and y+h <= height+0.01
    for a, b in itertools.combinations(r["panels"], 2):
        overlap = area(a["rect"], b["rect"])
        if overlap > 0.01:
            overlaps.append({"file": r["file"], "area": overlap})
    for label in r["labels"]:
        assert rect_valid(label["rect"])
        assert all(v+0.01 >= required for v, required in zip(label["rect"][2:], label["minimum_size"]))
    fade = r["mode"] == "collection_fade"
    value = 0.2 if fade else 3.0
    assert r["collection_text"] == f"倒计时：{value:.1f}s"
    assert abs(r["collection_value"]-value) < 1e-6 and r["collection_max"] == 3.0
    assert abs(r["collection_alpha"]-(0.2/0.35 if fade else 1)) < 1e-6
    text = "超载运行" if r["mode"] == "collection_overdrive" else "超载 60%"
    assert any(label["text"] == text for label in r["labels"])
    charge = r["panels"][2 if r["mode"] == "boss_all_collection" else 1]["rect"]
    collection = r["panels"][-1]["rect"]
    assert abs(charge[1]+charge[3]-(height-18)) < 0.1
    assert abs(charge[0]+charge[2]/2-width/2) < 0.1
    assert abs(collection[0]+collection[2]/2-width/2) < 0.1
    gap = charge[1]-(collection[1]+collection[3])
    assert abs(gap-(8 if after else -4)) < 0.1, (r["file"], gap)
assert len(overlaps) == (0 if after else 32)
print(json.dumps({"valid": not errors, "images": len(records), "sources": 13, "overlap_pairs": len(overlaps), "gap_px": 8 if after else -4, "errors": errors, "scope": "component native PNG SHA/font/AABB/frozen-source only; no Main, natural timing, performance or human acceptance"}))
