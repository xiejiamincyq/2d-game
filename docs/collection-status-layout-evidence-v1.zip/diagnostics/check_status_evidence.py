"""Read-only external verification of frozen combat-status component captures."""
import hashlib
import itertools
import json
import math
import sys
from pathlib import Path
from PIL import Image

project = Path(__file__).resolve().parents[3]
capture = Path(sys.argv[1]).resolve()
is_after = sys.argv[2] == "after"
manifest = json.loads((capture / "manifest.json").read_text(encoding="utf-8"))
errors = []
overlaps = []
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
expected = 32 if is_after else 16
if manifest.get("valid") is not True or len(manifest["images"]) != expected:
    errors.append("capture invalid or image count differs")
sizes = ((1280, 720), (960, 540), (1920, 1080), (2560, 1080))
modes = ("boss_combo", "boss_overdrive", "boss_all", "ordinary_toast")
timings = ("first_draw", "settled") if is_after else ("settled",)
actual_keys = {(tuple(r["viewport"]), r["mode"], r.get("timing", "settled")) for r in manifest["images"]}
if actual_keys != set(itertools.product(sizes, modes, timings)):
    errors.append("incomplete size/state/timing product")
for relative, digest in manifest["source_sha256"].items():
    frozen = (capture / "source" / relative).resolve()
    if not frozen.is_relative_to(capture / "source") or sha(frozen) != digest:
        errors.append(f"frozen source mismatch: {relative}")
    if is_after and sha(project / relative) != digest:
        errors.append(f"current source mismatch: {relative}")

def finite_rect(rect):
    return len(rect) == 4 and all(math.isfinite(v) for v in rect) and min(rect[2:]) > 0

def overlap(a, b):
    return max(0, min(a[0]+a[2], b[0]+b[2])-max(a[0], b[0])) * max(0, min(a[1]+a[3], b[1]+b[3])-max(a[1], b[1]))

seen = set()
for record in manifest["images"]:
    filename = record["file"]
    path = (capture / filename).resolve()
    if not path.is_relative_to(capture) or path.name != filename or filename in seen or sha(path) != record["sha256"]:
        errors.append(f"image path/hash mismatch: {filename}")
    seen.add(filename)
    with Image.open(path) as image:
        if list(image.size) != record["viewport"] or image.convert("L").getextrema()[0] == image.convert("L").getextrema()[1]:
            errors.append(f"flat or wrong-size image: {filename}")
    width, height = record["viewport"]
    for panel in record["panels"]:
        rect = panel["rect"]
        if not finite_rect(rect) or rect[0] < 0 or rect[1] < 0 or rect[0]+rect[2] > width+0.01 or rect[1]+rect[3] > height+0.01:
            errors.append(f"clipped/invalid panel: {filename}/{panel['path']}")
    for a, b in itertools.combinations(record["panels"], 2):
        area = overlap(a["rect"], b["rect"])
        if area > 0.01:
            overlaps.append({"file": filename, "area": area, "panels": [a["path"], b["path"]]})
    if is_after:
        if record.get("timing") not in ("first_draw", "settled"):
            errors.append(f"missing draw timing: {filename}")
        for label in record["labels"]:
            rect = label["rect"]
            if not finite_rect(rect) or any(actual+0.01 < required for actual, required in zip(rect[2:], label["minimum_size"])):
                errors.append(f"text content clipped: {filename}/{label['text']}")
        if record["mode"] in ("boss_combo", "boss_all") and record["combo"] != "连杀 x9999":
            errors.append(f"combo text missing: {filename}")
        if record["mode"] == "boss_overdrive" and record["combo"] != "超载 3.2s  无敌 · 全武器强化":
            errors.append(f"overdrive text missing: {filename}")
        if record["mode"] in ("boss_all", "ordinary_toast") and record["toast"] != "模块上线 // 激光协同强化":
            errors.append(f"toast text missing: {filename}")
        if record["mode"].startswith("boss"):
            grid, boss = record["panels"][0]["rect"], record["panels"][1]["rect"]
            combo = record["panels"][3]["rect"]
            expected_y = grid[1]+grid[3]+2+(max(boss[3], combo[3])-boss[3])/2
            if abs(boss[1]-expected_y) > 1:
                errors.append(f"Boss not in compact shared row: {filename}")
if is_after and overlaps:
    errors.append("visible panels overlap after fix")
print(json.dumps({"valid": not errors, "errors": errors, "images": len(seen), "source_bindings": len(manifest["source_sha256"]), "overlap_pairs": len(overlaps), "overlaps": overlaps, "scope": "frozen SHA, PNG dimensions/nonflat, actual panel/text AABBs; component-only, not natural/performance/human"}, ensure_ascii=False))
raise SystemExit(bool(errors))
