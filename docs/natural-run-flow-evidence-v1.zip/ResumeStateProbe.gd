extends SceneTree

func _initialize() -> void:
	var report: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://build/diagnostics/natural-run/os-checkpoint-v1.json"))
	var saved: Dictionary = report.final.snapshot
	var player: Node = load("res://scripts/actors/Player.gd").new()
	root.add_child(player)
	await process_frame
	player.set_physics_process(false)
	var upgrades: Node = load("res://scripts/systems/UpgradeSystem.gd").new()
	root.add_child(upgrades)
	upgrades.setup(player)
	print("PROBE restored_upgrades=", upgrades.restore_snapshot_state(saved), " restored_player=", player.restore_snapshot_state(saved.player))
	for pair in [["player", player.get_snapshot_state(), saved.player], ["settlement", upgrades.get_snapshot_state().settlement, saved.settlement]]:
		print("PROBE ", pair[0], " exact=", pair[1] == pair[2], " serialized=", JSON.stringify(pair[1]) == JSON.stringify(pair[2]))
		print("ACTUAL_", pair[0], " ", JSON.stringify(pair[1]))
		print("SAVED_", pair[0], " ", JSON.stringify(pair[2]))
		for field in pair[1]:
			if pair[1][field] != pair[2][field]:
				print("DIFF ", field, " actual=", pair[1][field], " saved=", pair[2][field])
	player.free()
	upgrades.free()
	await process_frame
	quit(0)
