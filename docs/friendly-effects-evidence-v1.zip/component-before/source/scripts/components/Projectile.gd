extends Area2D
class_name Projectile

const DamageTypes = preload("res://scripts/components/DamageTypes.gd")

var velocity: Vector2 = Vector2.ZERO
var damage: float = 1.0
var pierce: int = 0
var lifetime: float = 6.0
var target_group: StringName = &"enemies"
var hit_bodies: Array[Node] = []
var tint: Color = Color.CYAN
var radius: float = 4.0
var world_bounds: Rect2 = Rect2()
var damage_source: StringName = DamageTypes.PROJECTILE
var damage_multiplier_provider: Callable
var overdrive_visual: bool = false

func _ready() -> void:
	monitoring = true
	monitorable = false
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = radius
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)

func _physics_process(delta: float) -> void:
	global_position += velocity * delta
	if world_bounds.size != Vector2.ZERO and not world_bounds.has_point(global_position):
		queue_free()
		return
	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()

func _draw() -> void:
	if overdrive_visual:
		var direction := velocity.normalized()
		if direction == Vector2.ZERO:
			direction = Vector2.RIGHT
		var side := direction.orthogonal()
		var trail := PackedVector2Array([
			-direction * radius * 7.0,
			-direction * radius * 1.2 + side * radius * 1.1,
			direction * radius * 0.5,
			-direction * radius * 1.2 - side * radius * 1.1,
		])
		draw_colored_polygon(trail, Color(0.52, 0.18, 1.0, 0.26))
		draw_line(-direction * radius * 6.0, direction * radius * 0.5, Color(0.20, 1.0, 0.95, 0.68), 1.5)
		draw_circle(Vector2.ZERO, radius * 3.0, Color(0.71, 0.36, 1.0, 0.14))
		draw_circle(Vector2.ZERO, radius * 1.75, Color(0.78, 0.42, 1.0, 0.32))
	draw_rect(Rect2(Vector2(-radius, -radius), Vector2(radius * 2.0, radius * 2.0)), tint)
	draw_rect(Rect2(Vector2(-radius * 0.5, -radius * 0.5), Vector2(radius, radius)), Color.WHITE)

func _on_body_entered(body: Node) -> void:
	_try_hit(body)

func _on_area_entered(area: Area2D) -> void:
	_try_hit(area)

func _try_hit(node: Node) -> void:
	if not node.is_in_group(target_group) or hit_bodies.has(node):
		return
	hit_bodies.append(node)
	if node.has_method("take_damage"):
		var resolved_damage := get_resolved_damage()
		if node.is_in_group(&"enemies"):
			node.take_damage(resolved_damage, damage_source, velocity.normalized())
		else:
			node.take_damage(resolved_damage, damage_source)
	if pierce <= 0:
		queue_free()
	else:
		pierce -= 1

func get_resolved_damage() -> float:
	var multiplier := 1.0
	if damage_multiplier_provider.is_valid():
		multiplier = maxf(0.0, float(damage_multiplier_provider.call()))
	return damage * multiplier
