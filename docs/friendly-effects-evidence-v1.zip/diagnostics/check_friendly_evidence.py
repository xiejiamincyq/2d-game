"""Read-only component source/PNG/mechanics comparison, not natural acceptance."""
import hashlib
import itertools
import json
import re
from pathlib import Path
from PIL import Image

root = Path.cwd()
base = root / "build/diagnostics/friendly-effects"
manifests = []
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, source_count in (("friendly-before-v1", 14), ("friendly-after-v1", 15)):
    capture = base / name
    m = json.loads((capture / "manifest.json").read_text(encoding="utf-8"))
    assert m["valid"] is True and len(m["images"]) == 8 and len(m["mechanics"]) == 360
    assert len(m["source_sha256"]) == source_count
    keys = [(r["direction"], r["overdrive"]) for r in m["images"]]
    assert len(set(keys)) == 8 and set(keys) == set(itertools.product(range(4), (False, True)))
    for relative, digest in m["source_sha256"].items():
        path = (capture / "source" / relative).resolve()
        assert path.is_relative_to(capture / "source") and sha(path) == digest, relative
        if name.startswith("friendly-after"):
            assert sha(root / relative) == digest, relative
    for r in m["images"]:
        path = (capture / r["file"]).resolve()
        assert path.parent == capture and sha(path) == r["sha256"]
        with Image.open(path) as image:
            assert image.size == (1280, 720) and r["viewport"] == [1280, 720]
            assert len(set(image.convert("L").getextrema())) == 2
    manifests.append(m)
before, after = manifests
assert before["mechanics"] == after["mechanics"], "manual component mechanics changed"
for distance, (hits, damage) in zip((70, 140, 300), before["mechanics"][-1]["arc_hits"]):
    assert hits == 1 and abs(damage-20*(1-0.75*distance/620)) < 1e-5

def functions(text):
    starts = list(re.finditer(r"^func (\w+)\(", text, re.M))
    return {s.group(1): text[s.start():starts[i+1].start() if i+1 < len(starts) else len(text)].strip() for i, s in enumerate(starts)}

checked = 0
for relative in ("scripts/actors/Player.gd", "scripts/components/ArcPulseVisual.gd", "scripts/components/LaserBeam.gd", "scripts/components/SpikeTrap.gd", "scripts/components/FlameTrail.gd", "scripts/components/Projectile.gd", "scripts/ui/DroneLockReticle.gd", "scripts/effects/CombatVfx.gd", "scripts/components/TentacleAttack.gd"):
    old = functions((base / "friendly-before-v1/source" / relative).read_text(encoding="utf-8"))
    new = functions((root / relative).read_text(encoding="utf-8"))
    assert old.keys() == new.keys(), relative
    for name in old:
        if name in ("_draw", "_draw_landing_smoke"):
            continue
        a, b = old[name], new[name]
        if relative.endswith("Player.gd") and name == "_spawn_bullet":
            a = re.sub(r"^\tshot\.tint = .+\n", "", a, flags=re.M)
            b = re.sub(r"^\tshot\.tint = .+\n", "", b, flags=re.M)
        assert a == b, (relative, name)
        checked += 1
print(json.dumps({"valid": True, "native_images": 16, "source_bindings": [14, 15], "manual_steps": 360, "mechanical_differences": 0, "unchanged_functions": checked, "scope": "selected source hashes, 360 manual Arc/empty Spike/Vfx steps and 16 fixed-state PNG; no full mechanics coverage, natural input, performance or human acceptance"}))
