"""Current-source native flow and friendly RGB observations; no pixel opacity verdict."""
import hashlib
import json
import argparse
from pathlib import Path
from PIL import Image

root = Path.cwd()
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('suffixes', nargs='+', choices=['08', '09', '10'])
parser.add_argument('--partial', action='store_true', help='explicit partial check, never a three-seed verdict')
args = parser.parse_args()
if len(set(args.suffixes)) != len(args.suffixes) or (not args.partial and args.suffixes != ['08', '09', '10']):
    parser.error('complete check requires exactly 08 09 10; use --partial only for an explicit partial check')
base = root / 'build/diagnostics/friendly-effects'
natural = root / 'build/diagnostics/natural-run'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = []
binding = None
for suffix in args.suffixes:
    run = 'friendly-natural-' + suffix + '-pilot-v2'
    r = json.loads((natural / (run + '.json')).read_text(encoding='utf-8'))
    m = json.loads((natural / ('captures-' + run + '.json')).read_text(encoding='utf-8'))
    assert r['valid'] and r['terminal'] == 'victory' and r['restart_verified']
    assert r['real_saves_before'] == r['real_saves_after'] and len(r['real_saves_before']) == 6
    assert r['orphan_after'] <= r['orphan_before']
    assert r['source_sha256'] == m['source_sha256'] and len(m['source_sha256']) == 53
    if binding is not None:
        assert binding == m['source_sha256'], 'current runs have different selected sources'
    binding = m['source_sha256']
    for relative, digest in binding.items():
        assert sha(base / 'natural-current-source-v2' / relative) == sha(root / relative) == digest, relative
    assert m['overdrive_draw_frames'] > 0 and m['overdrive_body_tint_conflicts'] == 0
    extra = json.loads((natural / ('captures-' + run + '-overdrive.json')).read_text(encoding='utf-8'))
    assert extra['overdrive'] and extra['state'] == 'PLAYING'
    assert extra['player_modulate'] == [1.0, 1.0, 1.0, 1.0] and extra['source_sha256'] == binding
    frames = [v for clip in m['clips'].values() for v in clip]
    for frame in frames + [extra]:
        path = (root / frame['path']).resolve()
        assert path.is_relative_to(root) and sha(path) == frame['sha256']
        with Image.open(path) as image:
            assert image.size == (1280, 720)
            low, high = image.convert('L').getextrema()
            assert low < high
        if frame['overdrive']:
            assert frame['player_modulate'] == [1.0, 1.0, 1.0, 1.0]
    samples = r['samples']
    assert samples[-1]['pilot_random_heading_changes'] > 0
    assert all(abs(v['input'][a] - v['actual_input'][a]) < 1e-5 for v in samples for a in (0, 1))
    assert all(v['aim_dot'] >= .9999 for v in samples)
    rows.append({'run': run, 'seed': r['config']['seed'], 'map_seed': r['map_seed'], 'steps': len(samples),
                 'kills': r['result']['kills'], 'result_hp': r['result']['health'], 'min_hp': min(v['health'] for v in samples),
                 'overdrive_post_draw': m['overdrive_draw_frames'], 'tint_conflicts': m['overdrive_body_tint_conflicts'],
                 'frames': len(frames), 'missing': m['missing'], 'sources': 53, 'save_unchanged': True,
                 'escape_events': samples[-1]['pilot_escape_events'], 'orphans': [r['orphan_before'], r['orphan_after']],
                 'supplementary_overdrive_png': extra['path']})
print(json.dumps({'valid': True, 'complete_three_seed_check': not args.partial, 'runs': rows, 'scope': 'identical selected current source versions including seeded pilot; native flows and RGB multiplier evidence; no alpha-pixel opacity, identical trajectories, performance or human acceptance'}))
