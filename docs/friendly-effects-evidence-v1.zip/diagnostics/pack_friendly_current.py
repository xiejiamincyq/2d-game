"""Closed friendly-component/current-native evidence, not a playable build."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
base = root / 'build/diagnostics/friendly-effects'
natural = root / 'build/diagnostics/natural-run'
entries = {}
def add(path, name=None):
    path = path.resolve()
    assert path.is_relative_to(root) and path.is_file()
    name = name or path.relative_to(root).as_posix()
    assert name not in entries and not Path(name).is_absolute() and '..' not in Path(name).parts
    entries[name] = path
for directory, prefix in [('friendly-before-v1', 'component-before'), ('friendly-after-v1', 'component-after'),
                          ('natural-current-source-v2', 'source/current')]:
    origin = base / directory
    for path in sorted(origin.rglob('*')):
        if path.is_file():
            add(path, prefix + '/' + path.relative_to(origin).as_posix())
for name in ['palette-red-v1.log', 'palette-green-v1.log', 'overdrive-modulation-red-v1.log',
             'overdrive-modulation-green-v1.log', 'full-gate-v2.log', 'full-gate-v3.log', 'full-gate-pilot-v2.log',
             'recorder-green-v1.log', 'friendly-before-v1.log', 'friendly-after-v1.log',
             'component-external-v3.json', 'current-empty-before-v1.json', 'current-empty-reject-v2.log',
             'current-single-reject-v2.log', 'current-scope-v3.json', 'natural-current-registration-v2.json',
             'natural-08-pilot-v2.log', 'natural-09-pilot-v2.log', 'natural-10-pilot-v2.log',
             'pilot-native-six-v2.json', 'pilot-native-integrity-v2.json', 'current-09-six-v2.json',
             'current-10-six-v2.json', 'current-10-integrity-v2.json', 'extra-import-v1.log', 'extra-parse-v1.log',
             'check_friendly_evidence.py', 'check_friendly_current.py', 'pack_friendly_current.py']:
    add(base / name, 'diagnostics/' + name)
for relative in ['scripts/tests/FriendlyEffectPaletteTest.gd', 'scripts/tests/FriendlyEffectPaletteTest.gd.uid',
                 'scripts/tests/OverdriveTest.gd', 'scripts/tests/NaturalRunRenderedTest.gd', 'scripts/tests/DamageTest.gd',
                 'scripts/tests/Phase21Test.gd', 'scripts/tests/run_tests.ps1', 'scripts/art/VerifyFriendlyEffects.gd.uid',
                 'scripts/art/VerifyFriendlyNatural.gd.uid', 'scripts/effects/FriendlyEffectPalette.gd.uid',
                 'scripts/art/check_natural_render.py', 'scripts/art/check_natural_run_report.py']:
    add(root / relative, 'source/verification/' + relative)
selected_count = 0
for suffix in ['08', '09', '10']:
    run = 'friendly-natural-' + suffix + '-pilot-v2'
    for name in [run + '.json', 'captures-' + run + '.json', 'captures-' + run + '-overdrive.json']:
        add(natural / name, 'natural/' + name)
    manifest = json.loads((natural / ('captures-' + run + '.json')).read_text(encoding='utf-8'))
    selected = {frames[0]['path'] for frames in manifest['clips'].values() if frames}
    selected.update(manifest['clips']['boss'][i]['path'] for i in [15, 29])
    extra = json.loads((natural / ('captures-' + run + '-overdrive.json')).read_text(encoding='utf-8'))
    selected.add(extra['path'])
    for relative in sorted(selected):
        add(root / relative, 'natural/images/' + run + '/' + Path(relative).name)
    selected_count += len(selected)
target = root / 'docs/friendly-effects-evidence-v1.zip'
with ZipFile(target, 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(entries.items()):
        archive.write(path, name)
with ZipFile(target) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == len(set(archive.namelist())) == len(entries)
    for name, path in entries.items():
        assert archive.read(name) == path.read_bytes()
assert target.stat().st_size < 50_000_000
print(json.dumps({'entries': len(entries), 'bytes': target.stat().st_size,
                  'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'component_png': 16,
                  'natural_selected_png': selected_count, 'supplementary_overdrive_included': 3,
                  'scope': '16 component captures/14+15 source bindings/360 manual records; full 3 current run reports/53 selected frozen sources and selected native PNG only; not runnable or all-image archive'}))
