"""Serial native evidence and strict regression; never overwrite earlier runs."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
GODOT = Path(os.environ['LOCALAPPDATA']) / 'Microsoft/WinGet/Links/godot_console.exe'
CHANGED = ['scripts/actors/Enemy.gd', 'scripts/components/BossProjectilePattern.gd',
           'scripts/components/LobbedProjectile.gd', 'scripts/components/Projectile.gd',
           'scripts/components/TentacleAttack.gd']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def emit(path, data):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
def saves():
    store = Path(os.environ['APPDATA']) / 'Godot/app_userdata/废土清剿协议'
    return {name+suffix: digest(store/(name+suffix)) if (store/(name+suffix)).is_file() else 'absent'
            for name in ['five_minute_overdrive_run_v1.json', 'five_minute_overdrive_run_test_v1.json']
            for suffix in ['', '.tmp', '.bak']}
def guard():
    result = subprocess.run([sys.executable, '-X', 'utf8', '-B',
        'build/diagnostics/local-delivery/guard_user_files.py', 'after'], cwd=ROOT, capture_output=True)
    assert result.returncode == 0, result.stdout+result.stderr
    return json.loads(result.stdout)
def command(label, argv, cwd, timeout):
    directory = OUT / label
    directory.mkdir(exist_ok=False)
    before = saves()
    emit(directory/'registration.json', {'argv':argv, 'cwd':str(cwd), 'real_saves_before':before, 'protected_before':guard()})
    started = time.time()
    with (directory/'stdout.log').open('xb') as stdout, (directory/'stderr.log').open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=cwd, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        print(f'START {label} pid={process.pid}', flush=True)
        try:
            code = process.wait(timeout=timeout)
            timed_out = False
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'], capture_output=True)
            code = process.wait(timeout=10)
    errors = {}
    for name in ['stdout.log', 'stderr.log', 'engine.log']:
        path = directory/name
        errors[name] = re.findall(r'^.*(?:SCRIPT ERROR|ERROR:|TEST FAIL:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$', path.read_text(encoding='utf-8-sig', errors='replace'), re.M) if path.exists() else []
    after = saves()
    result = {'exit_code':code, 'timeout':timed_out, 'pid':process.pid, 'wall_seconds':time.time()-started,
              'errors':errors, 'real_saves_before':before, 'real_saves_after':after, 'protected_after':guard()}
    emit(directory/'closed.json', result)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    assert code == 0 and not timed_out and not any(errors.values()) and before == after
    return directory

mode = sys.argv[1]
if mode == 'captures':
    baseline = OUT/'baseline-v2'
    baseline.mkdir(exist_ok=False)
    # Complete source folders, excluding volatile cache/build and unrelated worktree paths.
    for name in ['assets', 'scenes', 'scripts', 'themes']:
        shutil.copytree(ROOT/name, baseline/name)
    for name in ['project.godot', 'export_presets.cfg']:
        shutil.copy2(ROOT/name, baseline/name)
    for name in CHANGED:
        shutil.copy2(OUT/'before-v1/source'/name, baseline/name)
    command('baseline-import-v2', [str(GODOT), '--headless', '--audio-driver', 'Dummy', '--path', str(baseline),
        '--import', '--log-file', str(OUT/'baseline-import-v2/engine.log')], baseline, 180)
    for run, cwd in [('before-v2', baseline), ('after-v2', ROOT)]:
        command(run+'-process', [str(GODOT), '--audio-driver', 'Dummy', '--path', str(cwd), '--resolution', '1280x720',
            '--log-file', str(OUT/(run+'-process')/'engine.log'), '--script', 'res://scripts/art/VerifyGroundWarningLayers.gd', '--', '--run='+run], cwd, 120)
    shutil.copytree(baseline/'build/diagnostics/ground-warning/before-v2', OUT/'before-v2')
elif mode in ['gate', 'gate-v2']:
    env = os.environ.copy()
    os.environ['GODOT_BIN'] = str(GODOT)
    os.environ['PYTHON_BIN'] = sys.executable
    command('full-gate-v1' if mode == 'gate' else 'full-gate-v2', ['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
        str(ROOT/'scripts/tests/run_tests.ps1')], ROOT, 600)
else:
    raise ValueError(mode)
