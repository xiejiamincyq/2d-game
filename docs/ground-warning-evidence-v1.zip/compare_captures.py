"""Compare original native pixels, alpha masks, metadata; contacts do not resize."""
import hashlib
import json
import sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent
reports = {phase: json.loads((OUT/f'{phase}-v2/report.json').read_text(encoding='utf-8')) for phase in ['before', 'after']}
rows = []
for old, new in zip(reports['before']['cases'], reports['after']['cases'], strict=True):
    assert (old['cardinal'],old['case']) == (new['cardinal'],new['case'])
    assert old['mechanics'] == new['mechanics']
    assert old['player_health'] == new['player_health'] and old['player_hit_timer'] == new['player_hit_timer']
    images = {}
    alphas = {}
    for phase, record in [('before',old), ('after',new)]:
        directory = OUT/f'{phase}-v2'
        for key, hashkey in [('file','sha256'),('player_alpha_file','player_alpha_sha256')]:
            path = directory/record[key]
            assert hashlib.sha256(path.read_bytes()).hexdigest() == record[hashkey]
        images[phase] = np.asarray(Image.open(directory/record['file']).convert('RGBA')).astype(np.int16)
        alphas[phase] = np.asarray(Image.open(directory/record['player_alpha_file']).convert('RGBA')).astype(np.int16)
    assert np.array_equal(alphas['before'],alphas['after']), 'Player changed'
    mask = alphas['after'][:,:,3] == 255
    # The genuine 8x8 friendly core intentionally remains above the actor.
    if new['case'] == 'friendly_trail':
        mask[124:132,146:154] = False
    row = {'cardinal':new['cardinal'], 'case':new['case'], 'opaque_player_pixels':int(mask.sum()),
           'same_full_pixels':bool(np.array_equal(images['before'],images['after'])),
           'health':new['player_health'], 'hit_timer':new['player_hit_timer']}
    for phase in ['before','after']:
        difference = np.max(np.abs(images[phase][:,:,:3]-alphas[phase][:,:,:3]),axis=2)
        row[phase+'_opaque_pixels_changed'] = int(((difference>1) & mask).sum())
    if new['case'] in ['control','hostile_core']:
        assert row['same_full_pixels']
    else:
        assert row['before_opaque_pixels_changed'] > 0, 'Fixture did not overlap the opaque actor'
        assert row['after_opaque_pixels_changed'] == 0, row
    rows.append(row)
for cardinal in range(4):
    cases = [r for r in reports['after']['cases'] if r['cardinal']==cardinal]
    for half in range(2):
        subset = cases[half*5:(half+1)*5]
        canvas = Image.new('RGB',(1280,560),'#123b3b')
        draw = ImageDraw.Draw(canvas)
        for col, record in enumerate(subset):
            for row, phase in enumerate(['before','after']):
                draw.text((col*256+4,row*280+3), f"{phase} {cardinal} {record['case']}", fill='white')
                canvas.paste(Image.open(OUT/f'{phase}-v2'/record['file']).convert('RGB'),(col*256,row*280+24))
        canvas.save(OUT/f'contact-{cardinal}-{half}.png')
summary = {'scope':'40 static real-component cases, 4 cardinal facings, unchanged native Player alpha; not natural movement/performance/human acceptance',
           'source_changes':[p for p,h in reports['before']['source_sha256'].items() if reports['after']['source_sha256'][p] != h],
           'mechanics_equal':True,'rows':rows}
with (OUT/(sys.argv[1] if len(sys.argv)>1 else 'comparison-v2.json')).open('x',encoding='utf-8') as stream:
    stream.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
