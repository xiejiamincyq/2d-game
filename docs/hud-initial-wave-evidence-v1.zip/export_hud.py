"""Fresh worktree snapshot/import/export; never alter the original source or old packages."""
import fnmatch
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

root = Path(__file__).resolve().parents[4]
output = root / "build/diagnostics/local-delivery/export-hud-initial-v1"
output.mkdir(exist_ok=False)
source = output / "source"
source.mkdir()
paths = [root / name for name in ("project.godot", "export_presets.cfg")]
for name in ("assets", "scenes", "scripts", "themes"):
    paths += [path for path in (root / name).rglob("*") if path.is_file()]
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
hashes = {path.relative_to(root).as_posix(): digest(path) for path in paths}
for path in paths:
    relative = path.relative_to(root)
    target = source / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
    if digest(target) != hashes[relative.as_posix()]:
        raise RuntimeError(f"Copy mismatch: {relative}")
patterns = re.search(r'^exclude_filter="([^"]+)"', (source / "export_presets.cfg").read_text(encoding="utf-8"), re.M).group(1).split(", ")
eligible = {name: value for name, value in hashes.items() if not any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)}
old = json.loads((root / "docs/local-playtest-handoff-v4.json").read_text(encoding="utf-8"))["source_sha256"]
changed = [name for name in eligible if eligible[name] != old.get(name)]
if set(eligible) != set(old) or set(changed) != {"scripts/Main.gd", "scripts/ui/HUD.gd"}:
    raise RuntimeError(f"Unexpected export input change: {changed}")
manifest = {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root).decode().strip(), "scope": "Worktree snapshot including original dirty resources; not clean HEAD", "source_sha256": hashes,
            "copy_files": len(paths), "copy_bytes": sum(path.stat().st_size for path in paths), "eligible_files": len(eligible), "changed_from_v4": changed}
(output / "input-manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
package = root / "build/playtest/5分钟超载-hud-initial-v1"
package.mkdir(exist_ok=False)
godot = "C:/Users/21604/AppData/Local/Microsoft/WinGet/Links/godot_console.exe"
for label, flags in [("import", ["--import"]), ("export", ["--export-release", "Windows Desktop", str(package / "five-minute-overdrive.exe")])]:
    argv = [godot, "--headless", "--audio-driver", "Dummy", "--path", str(source)] + flags
    with (output / f"{label}.log").open("x", encoding="utf-8") as stream:
        process = subprocess.Popen(argv, cwd=source, stdout=stream, stderr=subprocess.STDOUT)
        try:
            code = process.wait(timeout=110)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            raise
    log = (output / f"{label}.log").read_text(encoding="utf-8")
    if code or re.search(r"SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use", log):
        raise RuntimeError(f"{label} failed: {code}; preserve {label}.log")
record = dict(manifest, binaries={name: {"bytes": (package / name).stat().st_size, "sha256": digest(package / name)} for name in ("five-minute-overdrive.exe", "five-minute-overdrive.pck")}, package_relative_path=package.relative_to(root).as_posix())
(output / "export-receipt.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: record[key] for key in ("copy_files", "copy_bytes", "eligible_files", "changed_from_v4", "binaries", "package_relative_path")}, ensure_ascii=False))
