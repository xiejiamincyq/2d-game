"""Retain HUD regression and real EXE first-input evidence, not a clean-exit claim."""
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parents[4]
run = Path(__file__).resolve().parent
export = root / "build/diagnostics/local-delivery/export-hud-initial-v1"
record = json.loads((export / "export-receipt.json").read_text(encoding="utf-8"))
record["scope"] = "Actual retained EXE normal Start click showed first entrance HUD 1/6, remaining0. Exit0 but stderr has2 ObjectDB leaks; clean-exit gate FAILED. Not full-game, audio or performance proof."
record["full_gate"] = {"exit_code_observed": 0, "godot_suites": 69, "godot_assertions": 170082, "python_suites": 31, "python_tests": 235, "log": "hud-full-gate.log"}
record["native"] = {"pid": 9340, "exit_code_observed": 0, "exit_evidence_scope": "Direct retained PowerShell Process observation, no fabricated raw terminal file", "child_appdata": "build/diagnostics/exe-window/window-20261007-v1/appdata-hud", "arguments": ["--verbose", "--audio-driver", "Dummy", "--resolution", "1280x720", "--log-file", "hud-native-engine.log"], "clean_exit_gate_passed": False,
                    "warnings": (run / "hud-native-stderr.log").read_text(encoding="utf-8")}
store = Path(os.environ["APPDATA"]) / "Godot/app_userdata/废土清剿协议"
record["real_saves_after"] = {name + suffix: hashlib.sha256((store / (name + suffix)).read_bytes()).hexdigest() if (store / (name + suffix)).is_file() else "absent" for name in ("five_minute_overdrive_run_v1.json", "five_minute_overdrive_run_test_v1.json") for suffix in ("", ".tmp", ".bak")}
if any(value != "absent" for value in record["real_saves_after"].values()):
    raise RuntimeError("Formal save state changed")
members = {}
for name in ("hud-ui-red.log", "hud-state-red.log", "hud-ui-green.log", "hud-state-green.log", "hud-full-gate.log", "hud-native-engine.log", "hud-native-console.log", "hud-native-stderr.log", "export_hud.py", "package_hud_evidence.py", "observations-hud/observations.jsonl", "observations-hud/title.jpg", "observations-hud/first-start.jpg", "observations/second-start.jpg"):
    members[name] = (run / name).read_bytes()
for name in ("scripts/Main.gd", "scripts/ui/HUD.gd", "scripts/tests/UITest.gd", "scripts/tests/StateTest.gd"):
    members[name] = (root / name).read_bytes()
for name in ("import.log", "export.log", "input-manifest.json"):
    members["export/" + name] = (export / name).read_bytes()
members["handoff-v5.json"] = (json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode()
for row in (run / "observations-hud/observations.jsonl").read_text(encoding="utf-8").splitlines():
    shot = json.loads(row)["screenshot"]
    data = members["observations-hud/" + shot["filename"]]
    if len(data) != shot["bytes"] or hashlib.sha256(data).hexdigest() != shot["sha256"]:
        raise RuntimeError("Screenshot hash mismatch")
index = {"scope": record["scope"], "members": {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in members.items()}}
members["index.json"] = (json.dumps(index, ensure_ascii=False, indent=2) + "\n").encode()
archive = root / "docs/hud-initial-wave-evidence-v1.zip"
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as output:
    for name, data in members.items():
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    if output.testzip() is not None or set(output.namelist()) != set(members) or any(output.read(name) != data for name, data in members.items()):
        raise RuntimeError("Archive mismatch")
with (root / "docs/local-playtest-handoff-v5.json").open("x", encoding="utf-8") as output:
    output.write(members["handoff-v5.json"].decode())
print(json.dumps({"members": len(members), "bytes": archive.stat().st_size, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
