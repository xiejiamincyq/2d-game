extends SceneTree

const MainScript = preload("res://scripts/Main.gd")
const DamageTypes = preload("res://scripts/components/DamageTypes.gd")
const EnemyScript = preload("res://scripts/actors/Enemy.gd")
const TestSupport = preload("res://scripts/tests/TestSupport.gd")

var assertions := 0

func _assert_true(condition: bool, message: String) -> bool:
	assertions += 1
	if condition:
		return true
	push_error("TEST FAIL: StateTest: " + message)
	paused = false
	quit(1)
	return false

func _initialize() -> void:
	for path in ["res://scripts/systems/UpgradeSystem.gd", "res://scripts/ui/GameUI.gd"]:
		var source := FileAccess.get_file_as_string(path)
		if not _assert_true(source.find("get_tree().paused =") == -1, "%s still assigns SceneTree.paused" % path):
			return

	var scene: Node = MainScript.new()
	root.add_child(scene)
	await process_frame
	if not _assert_true(scene.run_state == scene.RunState.START, "Main did not start in START state"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "START did not hide and stop the reticle"):
		return
	if not _assert_true(scene._transition_to(scene.RunState.RESULT) == false, "illegal START to RESULT transition was accepted"):
		return
	scene._start_run()
	if not _assert_true(scene.run_state == scene.RunState.START and scene.player.is_entrance_active(), "start did not enter the player entrance gate"):
		return
	if not _assert_true(scene.ui.hud.wave_label.text == "波次 1 / %d    剩余 0" % scene.wave_director.waves.size(), "first visible entrance HUD did not reflect the director wave total"):
		return
	scene.player.advance_entrance(scene.player.get_entrance_duration() + 0.01)
	if not _assert_true(scene.run_state == scene.RunState.WAVE_INTRO and paused, "start did not enter WAVE_INTRO"):
		return
	scene.ui.wave_banner.finish_message()
	if not _assert_true(scene.run_state == scene.RunState.PLAYING and not paused, "wave banner did not enter PLAYING"):
		return
	if not _assert_true(scene.ui.aim_reticle.visible and scene.ui.aim_reticle.is_processing(), "PLAYING did not activate the reticle"):
		return
	var intro_boss: Node = scene.wave_director._spawn_boss_at(scene.player.global_position + Vector2(320.0, 0.0))
	if not _assert_true(intro_boss != null and scene.run_state == scene.RunState.BOSS_INTRO and paused, "Boss spawn did not pause the combat tree for its entrance reveal"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "Boss intro kept the reticle active"):
		return
	if not _assert_true(not intro_boss.visible and scene.ui.boss_entrance_overlay.visible, "Boss entrance did not replace the world Boss with a centered screen-space reveal"):
		return
	if not _assert_true(scene.ui.boss_entrance_overlay.get_intro_center().distance_to(scene.ui.root.size * 0.5) <= 0.01, "Boss entrance reveal was not centered in the viewport"):
		return
	intro_boss.set_physics_process(false)
	intro_boss._physics_process(intro_boss.get_attack_director().ENTRANCE_SECONDS + 0.01)
	if not _assert_true(scene.run_state == scene.RunState.PLAYING and not paused and intro_boss.visible and not scene.ui.boss_entrance_overlay.visible, "Boss entrance completion did not reveal the world Boss and resume combat"):
		return
	intro_boss.cancel_boss_attacks()
	intro_boss.queue_free()
	await process_frame
	if not _assert_true(
		is_instance_valid(scene.combat_feedback)
		and is_instance_valid(scene.combat_vfx)
		and is_instance_valid(scene.camera_effects),
		"run start did not build the combat feedback pipeline"
	):
		return
	scene.wave_director.active = false
	scene.wave_director._spawn_enemy(EnemyScript.EnemyKind.SCRAPPER)
	await process_frame
	var feedback_enemy: Node = scene.wave_director.active_enemies[-1]
	feedback_enemy.set_physics_process(false)
	feedback_enemy.health.set_process(false)
	var sparks_before: int = scene.combat_vfx.get_effect_count(&"spark")
	feedback_enemy.take_damage(1.0, DamageTypes.PROJECTILE, Vector2.RIGHT)
	if not _assert_true(
		scene.combat_vfx.get_effect_count(&"spark") == sparks_before + 1,
		"enemy damage did not reach the combat feedback pipeline"
	):
		return
	scene.combat_vfx.clear_all()
	feedback_enemy.health.current_health = 1.0
	feedback_enemy.take_damage(5.0, DamageTypes.PROJECTILE, Vector2.RIGHT)
	if not _assert_true(scene.kill_count == 1, "lethal damage did not reach the unique kill pipeline"):
		return
	if not _assert_true(
		scene.combat_vfx.get_effect_count(&"spark") >= 4
		and scene.combat_vfx.get_effect_count(&"debris") >= 6
		and scene.combat_vfx.get_effect_count(&"ring") >= 2,
		"a real enemy kill did not produce a clearly readable bounded burst"
	):
		return
	if not _assert_true(is_zero_approx(scene.camera_effects.trauma), "a light enemy kill triggered forbidden camera impact"):
		return
	scene._reset_combat_feedback()
	var permanent_fire_rate: float = scene.player.fire_rate * 1.5
	var permanent_weapon_damage: float = scene.player.weapon_damage * 1.25
	scene.player.fire_rate = permanent_fire_rate
	scene.player.weapon_damage = permanent_weapon_damage
	scene.player.set_overdrive_active(true)
	scene.player.set_dash_immunity_active(true)
	scene.combat_feedback.request_hit_stop(20.0)
	scene.camera_effects.request_impact(1.0, Vector2.RIGHT)
	scene.camera_effects._process(0.016)
	if not _assert_true(scene._transition_to(scene.RunState.WAVE_CLEAR) and paused, "PLAYING to WAVE_CLEAR did not pause"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "wave clear kept the reticle active"):
		return
	if not _assert_true(
		is_equal_approx(Engine.time_scale, 1.0)
		and scene.combat_vfx.get_total_effect_count() == 0
		and scene.player.get_node("PlayerCamera").offset == Vector2.ZERO
		and is_zero_approx(scene.player.get_node("PlayerCamera").rotation),
		"wave-clear transition did not reset combat feedback"
	):
		return
	if not _assert_true(
		is_equal_approx(scene.player.get_effective_fire_rate(), permanent_fire_rate),
		"wave-clear pause did not clear temporary fire-rate modifiers"
	):
		return
	if not _assert_true(
		is_equal_approx(scene.player.weapon_damage, permanent_weapon_damage),
		"temporary-state cleanup changed permanent weapon damage"
	):
		return
	if not _assert_true(
		is_equal_approx(scene.player.get_effective_damage_multiplier(DamageTypes.PROJECTILE), 1.0),
		"wave-clear pause did not clear temporary damage modifiers"
	):
		return
	if not _assert_true(not scene.player.is_damage_immune(), "wave-clear pause left temporary immunity active"):
		return
	if not _assert_true(scene._transition_to(scene.RunState.SETTLEMENT) and paused, "WAVE_CLEAR to SETTLEMENT was rejected"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "shop kept the reticle active"):
		return
	if not _assert_true(scene._transition_to(scene.RunState.WAVE_INTRO) and paused, "SETTLEMENT to WAVE_INTRO was rejected"):
		return
	if not _assert_true(scene._transition_to(scene.RunState.PLAYING) and not paused, "WAVE_INTRO to PLAYING did not resume"):
		return
	scene.player.set_overdrive_active(true)
	scene.player.set_dash_immunity_active(true)
	scene.combat_vfx.request_effect(&"ring", Vector2.ZERO)
	scene.combat_feedback.request_hit_stop(20.0)
	scene.camera_effects.request_impact(1.0, Vector2.UP)
	scene.camera_effects._process(0.016)
	if not _assert_true(scene._transition_to(scene.RunState.PAUSED) and paused, "PLAYING to PAUSED did not pause"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "pause kept the reticle active"):
		return
	if not _assert_true(
		is_equal_approx(Engine.time_scale, 1.0)
		and scene.combat_vfx.get_total_effect_count() == 0
		and scene.player.get_node("PlayerCamera").offset == Vector2.ZERO
		and is_zero_approx(scene.player.get_node("PlayerCamera").rotation),
		"manual pause transition did not reset combat feedback"
	):
		return
	if not _assert_true(not scene.player.is_damage_immune(), "manual pause left temporary immunity active"):
		return
	if not _assert_true(scene._transition_to(scene.RunState.PLAYING) and not paused, "PAUSED to PLAYING did not resume"):
		return
	if not _assert_true(scene.ui.aim_reticle.visible and scene.ui.aim_reticle.is_processing(), "resume did not reactivate the reticle"):
		return
	scene.player.set_overdrive_active(true)
	scene.combat_vfx.request_effect(&"debris", Vector2.ZERO)
	scene.combat_feedback.request_hit_stop(20.0)
	scene.camera_effects.request_impact(1.0, Vector2.LEFT)
	scene.camera_effects._process(0.016)
	if not _assert_true(scene._transition_to(scene.RunState.RESULT) and paused, "PLAYING to RESULT did not pause"):
		return
	if not _assert_true(not scene.ui.aim_reticle.visible and not scene.ui.aim_reticle.is_processing(), "result kept the reticle active"):
		return
	if not _assert_true(
		is_equal_approx(Engine.time_scale, 1.0)
		and scene.combat_vfx.get_total_effect_count() == 0
		and scene.player.get_node("PlayerCamera").offset == Vector2.ZERO
		and is_zero_approx(scene.player.get_node("PlayerCamera").rotation),
		"result transition did not reset combat feedback"
	):
		return
	if not _assert_true(
		is_equal_approx(scene.player.get_effective_fire_rate(), permanent_fire_rate)
		and is_equal_approx(scene.player.get_effective_damage_multiplier(DamageTypes.PROJECTILE), 1.0)
		and not scene.player.is_damage_immune(),
		"result transition did not restore runtime modifiers"
	):
		return

	TestSupport.stop_audio(scene.audio)
	await create_timer(0.25).timeout
	scene.combat_feedback.request_hit_stop(20.0)
	if not _assert_true(Engine.time_scale < 1.0, "exit cleanup precondition did not activate hit-stop"):
		return
	scene.queue_free()
	paused = false
	await process_frame
	if not _assert_true(is_equal_approx(Engine.time_scale, 1.0), "tree exit did not restore Engine.time_scale"):
		return
	await process_frame
	print("TEST PASS: StateTest %d" % assertions)
	quit(0)
