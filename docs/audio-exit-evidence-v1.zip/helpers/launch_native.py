"""Actual retained release EXE, process-local AppData, three-channel diagnostics."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[4]
run_id = sys.argv[1]
assert re.fullmatch(r"[a-z0-9-]{1,64}", run_id)
driver = sys.argv[2] if len(sys.argv) > 2 else "default"
assert driver in ("default", "Dummy")
output = root / "build/diagnostics/exe-window/audio-exit-v1" / run_id
output.mkdir(exist_ok=False)
profile = output / "appdata"
profile.mkdir()
receipt = json.loads((root / "build/diagnostics/local-delivery/export-audio-exit-v3/export-receipt.json").read_text(encoding="utf-8"))
package = root / receipt["package_relative_path"]
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else "absent"
for name, expected in receipt["binaries"].items():
    assert digest(package / name) == expected["sha256"] and (package / name).stat().st_size == expected["bytes"]
real_store = Path(os.environ["APPDATA"]) / "Godot/app_userdata/废土清剿协议"
def stores():
    return {name + suffix: digest(real_store / (name + suffix))
            for name in ("five_minute_overdrive_run_v1.json", "five_minute_overdrive_run_test_v1.json")
            for suffix in ("", ".tmp", ".bak")}
before = stores()
environment = dict(os.environ, APPDATA=str(profile))
argv = [str(package / "five-minute-overdrive.exe"), "--resolution", "1280x720", "--log-file", str(output / "engine.log")]
if driver != "default":
    argv += ["--audio-driver", driver]
started = time.time()
with (output / "stdout.log").open("x", encoding="utf-8") as stdout, (output / "stderr.log").open("x", encoding="utf-8") as stderr:
    process = subprocess.Popen(argv, cwd=package, env=environment, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
    start = {"scope": "actual release EXE ordinary window input, no injection or modified PCK; child APPDATA/resolution/log and declared driver only", "pid": process.pid, "argv": argv, "driver": driver, "started_epoch": started, "binaries": receipt["binaries"], "real_saves_before": before}
    (output / "launch.json").write_text(json.dumps(start, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"pid": process.pid, "run": run_id, "driver": driver}), flush=True)
    timed_out = False
    try:
        code = process.wait(timeout=300)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        code = process.wait(timeout=5)
errors = {}
for name in ("engine.log", "stdout.log", "stderr.log"):
    content = (output / name).read_text(encoding="utf-8") if (output / name).is_file() else ""
    errors[name] = re.findall(r"^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$", content, re.M)
result = dict(start, exit_code=code, timed_out=timed_out, wall_seconds=time.time() - started, real_saves_after=stores(), channel_errors=errors)
result["clean_exit_gate"] = code == 0 and not timed_out and not any(errors.values()) and result["real_saves_after"] == before
(output / "closed.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"pid": process.pid, "exit_code": code, "timed_out": timed_out, "errors": errors, "clean_exit_gate": result["clean_exit_gate"]}), flush=True)
raise SystemExit(0 if result["clean_exit_gate"] else 2)
