"""Freeze scoped original logs/screenshots/sources, excluding AppData and binaries."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[4]
run = Path(__file__).resolve().parent
prior = root / "build/diagnostics/exe-window/window-20261007-v1"
export = root / "build/diagnostics/local-delivery/export-audio-exit-v3"
receipt = json.loads((export / "export-receipt.json").read_text(encoding="utf-8"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name, value in receipt["source_sha256"].items():
    assert digest(root / name) == value, name
files = []
native = []
for name in ("title-dummy", "start-pause-default", "result-restart-default", "combat-dummy", "result-close-default"):
    directory = run / name
    closed = json.loads((directory / "closed.json").read_text(encoding="utf-8"))
    assert closed["clean_exit_gate"] and closed["binaries"] == receipt["binaries"]
    observations = [json.loads(line) for line in (directory / "observations/observations.jsonl").read_text(encoding="utf-8").splitlines()]
    for row in observations:
        shot = directory / "observations" / row["screenshot"]["filename"]
        assert digest(shot) == row["screenshot"]["sha256"]
    native.append({"run": name, "pid": closed["pid"], "driver": closed["driver"], "exit_code": closed["exit_code"], "timed_out": closed["timed_out"], "clean_exit_gate": closed["clean_exit_gate"], "real_saves_before": closed["real_saves_before"], "real_saves_after": closed["real_saves_after"], "observations": observations})
    files += [(f"native/{name}/{filename}", directory / filename) for filename in ("launch.json", "closed.json", "engine.log", "stdout.log", "stderr.log")]
    files += [(f"native/{name}/observations/{path.name}", path) for path in sorted((directory / "observations").iterdir())]
receipt.update(native_windows=native, verification={"full_gate": "71 Godot suites / 170771 assertions; 33 Python suites / 238 tests; actual exit 0; three diagnostic channels", "scope": "five short ordinary EXE sessions, not full EXE victory, physical audio listening, minimum hardware or rights approval", "protected_user_paths": 20})
handoff = root / "docs/local-playtest-handoff-v6.json"
handoff.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
for filename in ("audio-lifecycle-red-v3.log", "audio-lifecycle-drain-v2.log", "audio-lifecycle-rejection-red.log", "audio-lifecycle-rejection-red-v2.log", "main-close-red.log", "main-close-callback-red.log", "main-restart-seam-red.log", "main-close-green-v3.log", "runner-channel-red.log", "runner-channel-red-v2.log", "runner-channel-green.log", "main-close-timeout-check.log", "audio-full-gate-v1.log", "audio-full-gate-v2.log", "audio-full-gate-v3.log", "audio-full-gate-v4.log", "phase19-audio-green.log"):
    files.append(("tests/" + filename, prior / filename))
for filename in ("import.log", "export.log", "input-manifest.json", "export-receipt.json"):
    files.append(("export/" + filename, export / filename))
for filename in ("scripts/Main.gd", "scripts/systems/AudioManager.gd", "scripts/tests/AudioLifecycleTest.gd", "scripts/tests/MainCloseTest.gd", "scripts/tests/MainCloseTimeoutProbe.gd", "scripts/tests/Phase19Test.gd", "scripts/tests/run_tests.ps1", "scripts/tests/test_audio_exit_timeout.py", "scripts/tests/test_runner_audio_exit_gate.py"):
    files.append(("source/" + filename, root / filename))
for filename in ("export_audio.py", "launch_native.py", "package_evidence.py"):
    files.append(("helpers/" + filename, run / filename))
files.append(("helpers/exe_window_evidence.mjs", prior / "source/exe_window_evidence.mjs"))
files.append(("derived/local-playtest-handoff-v6.json", handoff))
archive = root / "docs/audio-exit-evidence-v1.zip"
index = [{"path": name, "bytes": path.stat().st_size, "sha256": digest(path)} for name, path in files]
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, path in files:
        zipped.write(path, name)
    zipped.writestr("evidence-index.json", json.dumps(index, ensure_ascii=False, indent=2) + "\n")
with zipfile.ZipFile(archive) as zipped:
    for row in index:
        data = zipped.read(row["path"])
        assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({"members": len(index) + 1, "bytes": archive.stat().st_size, "sha256": digest(archive), "screenshots": sum(len(item["observations"]) for item in native)}, ensure_ascii=False))
