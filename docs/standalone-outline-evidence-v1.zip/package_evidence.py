"""Write-once selected evidence archive; no EXE/PCK, private stores or old asset files."""
import hashlib
import json
from pathlib import Path
import zipfile

BASE=Path(__file__).resolve().parent
PROJECT=BASE.parents[2]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
selected=[BASE/name for name in ('prepare_baseline.py','boot_baseline.py','run_native.py','run_exe_title.py','standalone_native_probe.gd','guard_user_files.py','package_evidence.py','export-preload-red-v1.log','export-preload-green-v1.log','full-gate-v1.log','user-files-before-v1.json')]
selected += [BASE/'export-baseline-v1'/name for name in ('input-manifest.json','export.log','standalone-boot.json','standalone-boot.log','standalone-console.log')]
selected += [BASE/'export-fixed-v1'/name for name in ('input-manifest.json','export.log','export-success.log','standalone-boot.json','standalone-boot.log','standalone-console.log')]
selected += [BASE/'export-fixed-v1/native-v1'/name for name in ('console.log','engine.log')]
selected += [BASE/'export-fixed-v1/native-v2'/name for name in ('console.log','engine.log','launcher.json')]
selected += [BASE/'export-fixed-v1/packed-native-v3'/name for name in ('console.log','engine.log','launcher.json','native-report.json','title.png','gameplay-02.png','gameplay-05.png','gameplay-09.png')]
selected += [BASE/'export-fixed-v1/exe-native-title-v1'/name for name in ('console.log','engine.log','launcher.json','title00000000.png','title00000001.png','title00000002.png')]
selected += [BASE/'export-fixed-v1/source'/name for name in ('project.godot','export_presets.cfg','scenes/Main.tscn','scripts/Main.gd','scripts/effects/PlayerOcclusionOutline.gd','scripts/effects/PlayerOcclusionOutline.gd.uid','assets/art/shaders/player_occlusion_outline.gdshader','scripts/art/NaturalRunPolicy.gd')]
assert len(selected)==len(set(selected)) and all(path.is_file() and path.resolve().is_relative_to(BASE.resolve()) for path in selected)
destination=PROJECT/'docs/standalone-outline-evidence-v1.zip'
index_path=PROJECT/'docs/standalone-outline-evidence-index-v1.json'
assert not index_path.exists()
records=[]
with zipfile.ZipFile(destination,'x',zipfile.ZIP_DEFLATED) as archive:
    for path in selected:
        member=path.relative_to(BASE).as_posix()
        data=path.read_bytes()
        sha=hashlib.sha256(data).hexdigest()
        archive.writestr(member,data)
        records.append({'member':member,'original_path':path.relative_to(PROJECT).as_posix(),'bytes':len(data),'sha256':sha})
with zipfile.ZipFile(destination) as archive:
    assert archive.testzip() is None and sorted(archive.namelist())==sorted(item['member'] for item in records)
    for record,path in zip(records,selected):
        assert hashlib.sha256(archive.read(record['member'])).hexdigest()==record['sha256']==digest(path)
index={'archive':destination.name,'sha256':digest(destination),'bytes':destination.stat().st_size,'members':records,'scope':'Selected evidence, not portable full source or playable binaries; full input copies and EXE/PCK remain local. Failed probes retained. Private real save contents omitted.'}
with index_path.open('x',encoding='utf-8') as output:output.write(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
native=json.loads((BASE/'export-fixed-v1/packed-native-v3/native-report.json').read_text(encoding='utf-8'))
print(json.dumps({'archive_sha256':index['sha256'],'archive_bytes':index['bytes'],'members':len(records),'playing_steps':len(native['samples']),'random_heading_changes':native['pilot_random_heading_changes'],'escape_events':native['pilot_escape_events'],'kills':native['samples'][-1]['kills'],'state':native['state'],'map_seed':native['map_seed'],'pack_bytes':(BASE/'export-fixed-v1/package/five-minute-overdrive.pck').stat().st_size},ensure_ascii=False))
