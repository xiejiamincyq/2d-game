"""Normal exported EXE native title; movie frame readback, no external script."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent/'export-fixed-v1'
PACKAGE=BASE/'package'
OUTPUT=BASE/'exe-native-title-v1'
OUTPUT.mkdir(exist_ok=False)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'absent'
stores=Path(os.environ['APPDATA'])/'Godot/app_userdata/废土清剿协议'
def saves():return {name+suffix:digest(stores/(name+suffix)) for name in ('five_minute_overdrive_run_v1.json','five_minute_overdrive_run_test_v1.json') for suffix in ('','.tmp','.bak')}
before=saves()
log=OUTPUT/'engine.log'
argv=[str(PACKAGE/'five-minute-overdrive.exe'),'--audio-driver','Dummy','--resolution','1280x720','--log-file',str(log),'--write-movie',str(OUTPUT/'title.png'),'--quit-after','3']
start=time.monotonic()
timed_out=False
with (OUTPUT/'console.log').open('x',encoding='utf-8') as output:
    process=subprocess.Popen(argv,cwd=PACKAGE,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    try:code=process.wait(timeout=50)
    except subprocess.TimeoutExpired:timed_out=True;code=None
    finally:
        if process.poll() is None:process.kill();process.wait(timeout=10)
text=log.read_text(encoding='utf-8') if log.exists() else ''
errors=re.findall(r'^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$',text,re.MULTILINE)
from PIL import Image
images=[]
for path in sorted(OUTPUT.glob('*.png')):
    with Image.open(path) as image:
        image.load()
        images.append({'path':str(path),'sha256':digest(path),'size':list(image.size),'format':image.format,'nonflat':image.convert('RGB').getextrema()!=((0,0),(0,0),(0,0)) and any(a!=b for a,b in image.convert('RGB').getextrema())})
after=saves()
checks={'actual_exit_zero':code==0,'not_timed_out':not timed_out,'no_errors':not errors,'native_vulkan_header':'Vulkan' in text,'real_stores_unchanged':before==after,'native_title_frames':len(images)>=2 and all(item['size']==[1280,720] and item['format']=='PNG' and item['nonflat'] for item in images)}
record={'scope':'actual exported EXE native title, three fixed movie iterations; no gameplay, physical audio or realtime performance claim','argv':argv,'cwd':str(PACKAGE),'pid':process.pid,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'checks':checks,'valid':all(checks.values()),'errors':errors,'images':images,'real_save_hashes_before':before,'real_save_hashes_after':after,'exe_sha256':digest(PACKAGE/'five-minute-overdrive.exe'),'pck_sha256':digest(PACKAGE/'five-minute-overdrive.pck'),'log_sha256':digest(log)}
with (OUTPUT/'launcher.json').open('x',encoding='utf-8') as output:output.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
raise SystemExit(0 if record['valid'] else 2)
