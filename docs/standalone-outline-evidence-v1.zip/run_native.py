"""Packed game on editor engine; exported template disables external --script."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
RUN=BASE/'export-fixed-v1'
PACKAGE=RUN/'package'
run=sys.argv[1] if len(sys.argv)>1 else 'packed-native-v3'
assert re.fullmatch(r'[A-Za-z0-9_-]{1,48}',run)
OUTPUT=RUN/run
OUTPUT.mkdir(exist_ok=False)
stores=Path(os.environ['APPDATA'])/'Godot/app_userdata/废土清剿协议'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'absent'
def saves():return {name+suffix:digest(stores/(name+suffix)) for name in ('five_minute_overdrive_run_v1.json','five_minute_overdrive_run_test_v1.json') for suffix in ('','.tmp','.bak')}
before=saves()
log=OUTPUT/'engine.log'
engine=Path(os.environ['LOCALAPPDATA'])/'Microsoft/WinGet/Links/godot.exe'
argv=[str(engine),'--main-pack',str(PACKAGE/'five-minute-overdrive.pck'),'--audio-driver','Dummy','--resolution','1280x720','--max-fps','60','--log-file',str(log),'--script',str(BASE/'standalone_native_probe.gd'),'--','--output='+str(OUTPUT),'--policy='+str(RUN/'source/scripts/art/NaturalRunPolicy.gd')]
start=time.monotonic()
timed_out=False
with (OUTPUT/'console.log').open('x',encoding='utf-8') as output:
    process=subprocess.Popen(argv,cwd=PACKAGE,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    try:code=process.wait(timeout=150)
    except subprocess.TimeoutExpired:
        timed_out=True
        code=None
    finally:
        if process.poll() is None:
            process.kill();process.wait(timeout=10)
text=log.read_text(encoding='utf-8') if log.exists() else ''
errors=re.findall(r'^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$',text,re.MULTILINE)
report_path=OUTPUT/'native-report.json'
report=json.loads(report_path.read_text(encoding='utf-8')) if report_path.exists() else {}
after=saves()
checks={'actual_exit_zero':code==0,'no_errors':not errors,'unique_completion':text.count('STANDALONE_NATIVE_PROBE_COMPLETE')==1,'real_stores_unchanged':before==after,'native_display':report.get('display') not in (None,'headless'),'runtime_outline_in_pack':report.get('outline_exists') is True,'old_outline_excluded':report.get('old_outline_exists') is False,'authoring_excluded':not any(p.startswith(('res://scripts/art/','res://scripts/tests/')) for p in report.get('inventory',[])),'four_valid_captures':len(report.get('captures',[]))==4 and all(c['error']==0 and (c['width'],c['height'])==(1280,720) and digest(Path(c['path']))==c['sha256'] for c in report.get('captures',[])),'playing_samples':len(report.get('samples',[]))>=300,'random_pilot_active':report.get('pilot_random_heading_changes',0)>=1}
record={'scope':'packed Main on editor engine, NOT exported EXE gameplay','argv':argv,'cwd':str(PACKAGE),'pid':process.pid,'engine_sha256':digest(engine),'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'checks':checks,'valid':all(checks.values()),'errors':errors,'real_save_hashes_before':before,'real_save_hashes_after':after,'exe_sha256':digest(PACKAGE/'five-minute-overdrive.exe'),'pck_sha256':digest(PACKAGE/'five-minute-overdrive.pck'),'report_sha256':digest(report_path),'log_sha256':digest(log),'probe_sha256':digest(BASE/'standalone_native_probe.gd'),'policy_sha256':digest(RUN/'source/scripts/art/NaturalRunPolicy.gd')}
with (OUTPUT/'launcher.json').open('x',encoding='utf-8') as output:output.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
raise SystemExit(0 if record['valid'] else 2)
