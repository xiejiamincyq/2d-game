"""Hash only unrelated preexisting dirty paths before/after verification."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

PROJECT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
OWN={'scripts/Main.gd','scripts/tests/test_release_pack_policy.py',
    'scripts/art/PlayerOcclusionOutline.gd','scripts/art/PlayerOcclusionOutline.gd.uid',
    'scripts/effects/PlayerOcclusionOutline.gd','scripts/effects/PlayerOcclusionOutline.gd.uid',
    'scripts/tests/FriendlyEffectLayerTest.gd','scripts/tests/PlayerOcclusionOutlineTest.gd',
    'scripts/tests/ProjectileLandingVisualTest.gd','scripts/art/RenderPlayerOutlineRuntime.gd',
    'scripts/art/VerifyFriendlyLayerNatural.gd','scripts/art/VerifyFriendlyOcclusion.gd'}
def digest(relative):
    path=PROJECT/relative
    assert path.resolve().is_relative_to(PROJECT)
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else 'absent'
before_path=BASE/'user-files-before-v1.json'
if sys.argv[1]=='before':
    raw=subprocess.check_output(['git','status','--porcelain=v1','-z'],cwd=PROJECT).decode('utf-8')
    paths=[row[3:] for row in raw.split('\0') if row and row[3:] not in OWN]
    hashes={relative:digest(relative) for relative in paths}
    with before_path.open('x',encoding='utf-8') as output:
        output.write(json.dumps(hashes,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'protected_paths':len(hashes)}))
else:
    before=json.loads(before_path.read_text(encoding='utf-8'))
    changes=[relative for relative,value in before.items() if digest(relative)!=value]
    print(json.dumps({'protected_paths':len(before),'changed':changes},ensure_ascii=False))
    raise SystemExit(2 if changes else 0)
