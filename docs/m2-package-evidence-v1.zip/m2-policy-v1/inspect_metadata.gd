extends SceneTree

func _initialize() -> void:
	var output := ""
	var source := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			output = argument.trim_prefix("--output=")
		if argument.begins_with("--source="):
			source = argument.trim_prefix("--source=")
	if output.is_empty() or source.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	var config := ConfigFile.new()
	if config.parse("[global]\n" + FileAccess.get_file_as_string("res://.godot/global_script_class_cache.cfg")) != OK:
		quit(2)
		return
	var uid_mapping: Dictionary = {}
	_collect_uids(source.path_join("scripts"), source, uid_mapping)
	var file := FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		quit(2)
		return
	file.store_string(JSON.stringify({"process_id": OS.get_process_id(), "classes": config.get_value("global", "list"), "script_uid_mapping": uid_mapping, "scope": "Parsed exported class cache and ResourceUID lookup for packed script identifiers from frozen source .uid files; not a full UID binary cache equality proof."}, "\t"))
	file.close()
	print("M2_METADATA_INSPECT_COMPLETE")
	quit()

func _collect_uids(directory: String, source: String, mapping: Dictionary) -> void:
	for file in DirAccess.get_files_at(directory):
		if not file.ends_with(".gd.uid"):
			continue
		var path := directory.path_join(file)
		var packed_path := "res://" + path.trim_prefix(source + "/").trim_suffix(".uid")
		if not ResourceLoader.exists(packed_path):
			continue
		var text := FileAccess.get_file_as_string(path).strip_edges()
		var uid := ResourceUID.text_to_id(text)
		mapping[packed_path] = {"uid": text, "present": ResourceUID.has_id(uid), "mapped_path": ResourceUID.get_id_path(uid) if ResourceUID.has_id(uid) else ""}
	for child in DirAccess.get_directories_at(directory):
		_collect_uids(directory.path_join(child), source, mapping)
