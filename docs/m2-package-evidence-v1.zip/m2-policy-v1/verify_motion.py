"""Require actual world displacement, not merely pilot decisions or pressed input."""
import hashlib
import json
import math
from pathlib import Path
import sys

path=Path(sys.argv[1])
output=Path(sys.argv[2])
report=json.loads(path.read_text(encoding='utf-8'))
samples=report['samples']
spans=[max(s['position'][i] for s in samples)-min(s['position'][i] for s in samples) for i in (0,1)]
moving_steps=sum(math.dist(a['position'],b['position'])>2 for a,b in zip(samples,samples[1:]))
checks={'at_least_300_samples':len(samples)>=300,'world_span_at_least_150px':math.hypot(*spans)>=150,'at_least_60_moving_steps':moving_steps>=60}
result={'report':str(path),'report_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'samples':len(samples),'xy_span':spans,'moving_steps_gt_2px':moving_steps,'checks':checks,'valid':all(checks.values()),'scope':'Limited short-probe motion evidence, not a general obstacle escape or full-run pass.'}
with output.open('x',encoding='utf-8') as file:file.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['valid'] else 2)
