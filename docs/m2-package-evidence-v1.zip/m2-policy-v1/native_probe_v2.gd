extends "C:/Users/21604/Documents/2D game/.worktrees/5分钟超载/build/diagnostics/local-delivery/standalone_native_probe.gd"

var neutral_steps := 0
var neutral_reported := false

func _input() -> void:
	if finishing or not is_instance_valid(scene.player):
		return
	if scene.player.spawn_input_guard_active:
		for action in ["move_left", "move_right", "move_up", "move_down", "fire"]:
			Input.action_release(action)
		neutral_steps += 1
		return # Let the real Player observe zero input; never write the guard itself.
	if not neutral_reported:
		print("STANDALONE_NEUTRAL_INPUT_OBSERVED steps=%d" % neutral_steps)
		neutral_reported = true
	super._input()
