extends SceneTree

func _initialize() -> void:
	var output := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			output = argument.trim_prefix("--output=")
	if output.is_empty() or DirAccess.dir_exists_absolute(output):
		quit(2)
		return
	if DirAccess.make_dir_recursive_absolute(output) != OK:
		quit(2)
		return
	for file in DirAccess.get_files_at("res://.godot/exported/133200997"):
		if not file.ends_with(".scn"):
			continue
		var path := "res://.godot/exported/133200997/" + file
		var scene := load(path)
		if not scene is PackedScene or ResourceSaver.save(scene, output.path_join(file.trim_suffix(".scn") + ".tscn")) != OK:
			quit(2)
			return
	var cache := FileAccess.open(output.path_join("global_script_class_cache.cfg"), FileAccess.WRITE)
	cache.store_string(FileAccess.get_file_as_string("res://.godot/global_script_class_cache.cfg"))
	cache.close()
	print("M2_SCENES_INSPECT_COMPLETE")
	quit()
