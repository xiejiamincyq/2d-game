"""Fresh package: actual EXE native title, then packed-engine gameplay diagnostic."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

BASE=Path(__file__).resolve().parent
DELIVERY=BASE.parent
RUN=DELIVERY/'export-m2-clean-v1'
PACKAGE=RUN/'package'
stores=Path(os.environ['APPDATA'])/'Godot/app_userdata/废土清剿协议'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'absent'
def saves():return {name+suffix:digest(stores/(name+suffix)) for name in ('five_minute_overdrive_run_v1.json','five_minute_overdrive_run_test_v1.json') for suffix in ('','.tmp','.bak')}

for kind in ('exe-title','packed-gameplay'):
    output=RUN/kind
    output.mkdir(exist_ok=False)
    log=output/'engine.log'
    if kind=='exe-title':
        argv=[str(PACKAGE/'five-minute-overdrive.exe'),'--audio-driver','Dummy','--resolution','1280x720','--log-file',str(log),'--write-movie',str(output/'title.png'),'--quit-after','3']
    else:
        engine=Path(os.environ['LOCALAPPDATA'])/'Microsoft/WinGet/Links/godot.exe'
        argv=[str(engine),'--main-pack',str(PACKAGE/'five-minute-overdrive.pck'),'--audio-driver','Dummy','--resolution','1280x720','--max-fps','60','--log-file',str(log),'--script',str(DELIVERY/'standalone_native_probe.gd'),'--','--output='+str(output),'--policy='+str(RUN/'source/scripts/art/NaturalRunPolicy.gd')]
    before=saves()
    start=time.monotonic()
    timed_out=False
    with (output/'console.log').open('x',encoding='utf-8') as stream:
        process=subprocess.Popen(argv,cwd=PACKAGE,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        try:code=process.wait(timeout=50)
        except subprocess.TimeoutExpired:timed_out=True;code=None
        finally:
            if process.poll() is None:process.kill();process.wait(timeout=10)
    text=log.read_text(encoding='utf-8') if log.exists() else ''
    errors=re.findall(r'^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$',text,re.MULTILINE)
    after=saves()
    report_path=output/'native-report.json'
    report=json.loads(report_path.read_text(encoding='utf-8')) if report_path.exists() else {}
    from PIL import Image
    images=[]
    for path in sorted(output.glob('*.png')):
        with Image.open(path) as image:
            image.load()
            images.append({'path':str(path),'sha256':digest(path),'size':list(image.size),'format':image.format,'nonflat':any(a!=b for a,b in image.convert('RGB').getextrema())})
    checks={'actual_exit_zero':code==0,'not_timed_out':not timed_out,'no_errors':not errors,'native_vulkan_header':'Vulkan' in text,'real_stores_unchanged':before==after,'native_pngs':len(images)==(3 if kind=='exe-title' else 4) and all(item['size']==[1280,720] and item['format']=='PNG' and item['nonflat'] for item in images)}
    if kind=='exe-title':
        reference=DELIVERY/'export-fixed-v1/exe-native-title-v1/title00000000.png'
        checks['title_matches_previous_package']=all(item['sha256']==digest(reference) for item in images)
    else:
        checks.update({'unique_completion':text.count('STANDALONE_NATIVE_PROBE_COMPLETE')==1,'report_pid':report.get('process_id')==process.pid,'playing_samples':len(report.get('samples',[]))>=300,'outline_present':report.get('outline_exists') is True,'random_pilot_active':report.get('pilot_random_heading_changes',0)>=1,'no_m2_members':not any('player_m2_' in path for path in report.get('inventory',[]))})
    record={'scope':'actual exported EXE native title, three fixed movie iterations' if kind=='exe-title' else 'packed Main on editor engine, ten-second input diagnostic, NOT exported EXE gameplay','argv':argv,'cwd':str(PACKAGE),'pid':process.pid,'exit_code':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,'checks':checks,'valid':all(checks.values()),'errors':errors,'images':images,'real_save_hashes_before':before,'real_save_hashes_after':after,'exe_sha256':digest(PACKAGE/'five-minute-overdrive.exe'),'pck_sha256':digest(PACKAGE/'five-minute-overdrive.pck'),'log_sha256':digest(log),'report_sha256':digest(report_path),'probe_sha256':digest(DELIVERY/'standalone_native_probe.gd'),'policy_sha256':digest(RUN/'source/scripts/art/NaturalRunPolicy.gd')}
    with (output/'launcher.json').open('x',encoding='utf-8') as stream:stream.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'kind':kind,'valid':record['valid'],'checks':checks,'wall_seconds':record['wall_seconds']},ensure_ascii=False),flush=True)
    if not record['valid']:raise SystemExit(2)
