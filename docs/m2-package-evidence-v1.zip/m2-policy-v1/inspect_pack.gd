extends SceneTree

var inventory: Dictionary = {}

func _scan(path: String) -> void:
	for file in DirAccess.get_files_at(path):
		var resource := path.path_join(file)
		inventory[resource] = FileAccess.get_sha256(resource)
	for directory in DirAccess.get_directories_at(path):
		_scan(path.path_join(directory))

func _initialize() -> void:
	var output := ""
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			output = argument.trim_prefix("--output=")
	if output.is_empty() or FileAccess.file_exists(output):
		quit(2)
		return
	_scan("res://")
	var retired: Dictionary = {}
	for action in ["ready", "move", "fire"]:
		var path := "res://assets/art/actors/player/player_m2_%s_120yaw.png" % action
		retired[path] = ResourceLoader.exists(path)
	var current: Dictionary = {}
	for path in ["res://assets/art/actors/player/player_chibi_b_cardinal_atlas_v1.png", "res://assets/art/actors/player/player_chibi_b_weapon_cardinal_atlas_v1.png", "res://scripts/effects/PlayerOcclusionOutline.gd"]:
		current[path] = ResourceLoader.exists(path)
	var file := FileAccess.open(output, FileAccess.WRITE)
	if file == null:
		quit(2)
		return
	file.store_string(JSON.stringify({"process_id": OS.get_process_id(), "inventory": inventory, "retired_exists": retired, "current_exists": current, "scope": "Read-only mounted PCK inventory on editor engine; no Main instantiated, no gameplay or save access."}, "\t"))
	file.close()
	print("M2_PACK_INSPECT_COMPLETE")
	quit()
