"""Reuse the stage driver in a new directory; strengthen its gameplay input gate."""
from pathlib import Path
import runpy

BASE=Path(__file__).resolve().parent
original=(BASE/'run_native.py').read_text(encoding='utf-8')
# This diagnostic-specific adaptation preserves the first attempt unchanged.
source=original.replace("for kind in ('exe-title','packed-gameplay'):","for kind in ('packed-gameplay-v2',):")
source=source.replace("str(DELIVERY/'standalone_native_probe.gd')","str(BASE/'native_probe_v2.gd')")
source=source.replace("digest(DELIVERY/'standalone_native_probe.gd')","digest(BASE/'native_probe_v2.gd')")
source=source.replace("'random_pilot_active':report.get('pilot_random_heading_changes',0)>=1,","'random_pilot_active':report.get('pilot_random_heading_changes',0)>=1,'neutral_input_observed':text.count('STANDALONE_NEUTRAL_INPUT_OBSERVED')==1,")
assert source!=original and "for kind in ('exe-title','packed-gameplay'):" not in source
exec(compile(source,str(BASE/'run_native.py'),'exec'),{'__file__':str(BASE/'run_native.py'),'__name__':'__main__'})
