"""Close selected raw evidence; preserve the rejected no-motion run."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

BASE=Path(__file__).resolve().parent
DELIVERY=BASE.parent
PROJECT=DELIVERY.parents[2]
RUN=DELIVERY/'export-m2-clean-v1'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8'))
before=read(BASE/'pack-before.json')
after=read(BASE/'pack-after.json')
old,new=before['inventory'],after['inventory']
removed=sorted(old.keys()-new.keys())
changed=sorted(path for path in old.keys()&new.keys() if old[path]!=new[path])
assert len(old)==187 and len(new)==181 and len(removed)==6 and not new.keys()-old.keys()
assert all('player_m2_' in path and path.endswith(('.ctex','.png.import')) for path in removed)
assert all(before['retired_exists'].values()) and not any(after['retired_exists'].values()) and all(after['current_exists'].values())
assert not any(path.startswith(('res://scripts/art/','res://scripts/tests/')) for path in new)
assert len(changed)==9 and all(path.endswith(('.scn','global_script_class_cache.cfg','uid_cache.bin')) for path in changed)
scenes=[]
for path in sorted((BASE/'scenes-before').glob('*.tscn')):
    other=BASE/'scenes-after'/path.name
    normalized=[]
    for item in (path,other):
        text=item.read_text(encoding='utf-8')
        ids=re.findall(r'^\[ext_resource type="Script" path="[^"]+" id="([^"]+)"\]$',text,re.MULTILINE)
        assert len(ids)==1 and text.count('[node ')==1 and '[sub_resource ' not in text
        text=re.sub(r' unique_id=\d+(?=\])','',text.replace('"'+ids[0]+'"','"SCRIPT"'))
        normalized.append(text)
    assert normalized[0]==normalized[1]
    scenes.append({'name':path.name,'before_sha256':digest(path),'after_sha256':digest(other),'normalized_sha256':hashlib.sha256(normalized[0].encode()).hexdigest(),'scope':'Exact converted text after normalizing its one local script reference label and root unique_id; not arbitrary scene semantic equivalence.'})
assert len(scenes)==7
a,b=read(BASE/'metadata-before.json'),read(BASE/'metadata-after.json')
assert sorted(a['classes'],key=lambda row:row['class'])==sorted(b['classes'],key=lambda row:row['class'])
assert a['script_uid_mapping']==b['script_uid_mapping'] and len(b['script_uid_mapping'])==55
assert all(row['present'] and row['mapped_path']==path for path,row in b['script_uid_mapping'].items())
old_input=read(DELIVERY/'export-fixed-v1/input-manifest.json')['source_sha256']
new_input=read(RUN/'input-manifest.json')['source_sha256']
input_changed=sorted(path for path in old_input.keys()|new_input.keys() if old_input.get(path)!=new_input.get(path))
assert input_changed==['export_presets.cfg','scripts/tests/test_release_pack_policy.py']
boot=read(RUN/'standalone-boot.json')
native=read(RUN/'exe-title/launcher.json')
gameplay=read(RUN/'packed-gameplay-v2/launcher.json')
assert boot['valid'] and native['valid'] and gameplay['valid'] and read(BASE/'motion-green.json')['valid']
assert read(BASE/'motion-red.json')['valid'] is False
report=read(RUN/'packed-gameplay-v2/native-report.json')
summary={'scope':'M2 export-only removal and short-probe input correction; not full project delivery','input_changed':input_changed,'before_pack_bytes':6848612,'after_pack_bytes':(RUN/'package/five-minute-overdrive.pck').stat().st_size,'after_pack_sha256':digest(RUN/'package/five-minute-overdrive.pck'),'members_before':len(old),'members_after':len(new),'removed':removed,'changed_generated_members':changed,'converted_scene_checks':scenes,'class_entries_unordered_equal':len(b['classes']),'packed_script_uid_mappings_equal':55,'uid_cache_binary_fully_compared':False,'boot':boot['valid'],'actual_exe_native_title':native['valid'],'packed_editor_gameplay':gameplay['valid'],'motion_red':read(BASE/'motion-red.json'),'motion_green':read(BASE/'motion-green.json'),'native_samples':len(report['samples']),'random_heading_changes':report['pilot_random_heading_changes'],'escape_events':report['pilot_escape_events'],'map_seed':report['map_seed'],'final_kills':report['samples'][-1]['kills'],'final_hp':report['samples'][-1]['hp'],'final_state':report['state']}
summary_path=PROJECT/'docs/m2-package-summary-v1.json'
with summary_path.open('x',encoding='utf-8') as output:output.write(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
selected=sorted(path for path in BASE.rglob('*') if path.is_file())
selected += [DELIVERY/name for name in ('prepare_baseline.py','boot_baseline.py','standalone_native_probe.gd','guard_user_files.py','user-files-before-v1.json')]
selected += [RUN/name for name in ('input-manifest.json','import.log','export.log','standalone-boot.json','standalone-boot.log','standalone-console.log')]
for directory in ('exe-title','packed-gameplay','packed-gameplay-v2'):
    selected += [path for path in sorted((RUN/directory).iterdir()) if path.is_file() and path.suffix in ('.json','.png','.log') and path.name!='isolated-run.json']
selected += [RUN/'source'/name for name in ('project.godot','export_presets.cfg','scripts/tests/test_release_pack_policy.py','scripts/art/NaturalRunPolicy.gd')]
assert len(selected)==len(set(selected)) and all(path.resolve().is_relative_to(DELIVERY.resolve()) for path in selected)
archive_path=PROJECT/'docs/m2-package-evidence-v1.zip'
records=[]
with zipfile.ZipFile(archive_path,'x',zipfile.ZIP_DEFLATED) as archive:
    for path in selected:
        member=path.relative_to(DELIVERY).as_posix()
        data=path.read_bytes()
        archive.writestr(member,data)
        records.append({'member':member,'original_path':path.relative_to(PROJECT).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and sorted(archive.namelist())==sorted(row['member'] for row in records)
    for row,path in zip(records,selected):assert hashlib.sha256(archive.read(row['member'])).hexdigest()==row['sha256']==digest(path)
index={'archive':archive_path.name,'sha256':digest(archive_path),'bytes':archive_path.stat().st_size,'scope':'Selected evidence; EXE/PCK/full input copies stay local; no real save contents or old atlas source files. Both short probes retained, only v2 passes motion gate.','members':records}
with (PROJECT/'docs/m2-package-evidence-index-v1.json').open('x',encoding='utf-8') as output:output.write(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'members':len(records),'archive_bytes':index['bytes'],'archive_sha256':index['sha256'],'pack_bytes':summary['after_pack_bytes'],'native_samples':summary['native_samples'],'class_entries':len(b['classes'])},ensure_ascii=False))
