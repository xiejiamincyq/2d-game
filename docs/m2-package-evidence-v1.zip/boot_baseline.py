"""Run the actual standalone EXE from its package folder, no source fallback."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import sys

run=sys.argv[1] if len(sys.argv)>1 else 'export-baseline-v1'
assert re.fullmatch(r'[A-Za-z0-9_-]{1,48}',run)
BASE=Path(__file__).resolve().parent/run
PACKAGE=BASE/'package'
LOG=BASE/'standalone-boot.log'
assert not LOG.exists()
stores=Path(os.environ['APPDATA'])/'Godot/app_userdata/废土清剿协议'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else 'absent'
def save_hashes():
    return {name+suffix:digest(stores/(name+suffix)) for name in
        ('five_minute_overdrive_run_v1.json','five_minute_overdrive_run_test_v1.json') for suffix in ('','.tmp','.bak')}
before=save_hashes()
argv=[str(PACKAGE/'five-minute-overdrive.exe'),'--headless','--audio-driver','Dummy',
      '--log-file',str(LOG),'--quit-after','120']
start=time.monotonic()
with (BASE/'standalone-console.log').open('x',encoding='utf-8') as output:
    process=subprocess.Popen(argv,cwd=PACKAGE,stdout=output,stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        code=process.wait(timeout=50)
    finally:
        if process.poll() is None:
            process.kill();process.wait(timeout=10)
text=LOG.read_text(encoding='utf-8') if LOG.exists() else ''
errors=re.findall(r'^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$',text,re.MULTILINE)
after=save_hashes()
record={'argv':argv,'cwd':str(PACKAGE),'pid':process.pid,'exit_code':code,'wall_seconds':time.monotonic()-start,
    'real_save_hashes_before':before,'real_save_hashes_after':after,'real_saves_unchanged':before==after,
    'exe_sha256':digest(PACKAGE/'five-minute-overdrive.exe'),'pck_sha256':digest(PACKAGE/'five-minute-overdrive.pck'),
    'log_sha256':digest(LOG),'errors':errors,'valid':code==0 and bool(text) and not errors and before==after,
    'scope':'actual standalone headless title startup, no source directory; not native visuals or gameplay acceptance'}
with (BASE/'standalone-boot.json').open('x',encoding='utf-8') as output:
    output.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False))
raise SystemExit(0 if record['valid'] else 2)
