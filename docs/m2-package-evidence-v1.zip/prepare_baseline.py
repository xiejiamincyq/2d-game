"""Build from a byte-verified local copy, preserving the dirty worktree."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import re

PROJECT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
run=sys.argv[1] if len(sys.argv)>1 else 'export-baseline-v1'
assert re.fullmatch(r'[A-Za-z0-9_-]{1,48}',run)
ROOT=BASE/run
ROOT.mkdir(exist_ok=False)
stage=ROOT/'source'
stage.mkdir()
files=[PROJECT/name for name in ('project.godot','export_presets.cfg')]
for name in ('assets','scenes','scripts','themes'):
    files.extend(path for path in (PROJECT/name).rglob('*') if path.is_file())

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

hashes={}
for source in files:
    assert source.resolve().is_relative_to(PROJECT)
    relative=source.relative_to(PROJECT)
    destination=stage/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    hashes[relative.as_posix()]=digest(source)
    shutil.copyfile(source,destination)
    assert digest(destination)==hashes[relative.as_posix()]
record={'scope':'actual worktree runtime folders, including preexisting dirty files; local-only copy, no source edits',
        'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=PROJECT,text=True).strip(),
        'source_sha256':hashes,'copied_files':len(hashes),'copied_bytes':sum(path.stat().st_size for path in files)}
with (ROOT/'input-manifest.json').open('x',encoding='utf-8') as output:
    output.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({key:record[key] for key in ('head','copied_files','copied_bytes')}))
