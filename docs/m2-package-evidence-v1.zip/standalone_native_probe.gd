extends SceneTree

var output := ""
var policy_path := ""
var scene: Node
var pilot: RefCounted
var samples: Array[Dictionary] = []
var captures: Array[Dictionary] = []
var inventory: Array[String] = []
var started := 0
var last_capture := -1
var finishing := false

func _initialize() -> void:
	for argument in OS.get_cmdline_user_args():
		if argument.begins_with("--output="):
			output = argument.trim_prefix("--output=")
		if argument.begins_with("--policy="):
			policy_path = argument.trim_prefix("--policy=")
	if output.is_empty() or not DirAccess.dir_exists_absolute(output) or DisplayServer.get_name() == "headless":
		quit(2)
		return
	call_deferred("_begin")

func _scan(path: String) -> void:
	for file in DirAccess.get_files_at(path):
		inventory.append(path.path_join(file))
	for directory in DirAccess.get_directories_at(path):
		_scan(path.path_join(directory))

func _begin() -> void:
	_scan("res://")
	inventory.sort()
	var policy_script = load(policy_path) # External input-only diagnostic, never gameplay fallback.
	pilot = policy_script.new(20260908)
	change_scene_to_file("res://scenes/Main.tscn")
	await scene_changed
	scene = current_scene
	scene.snapshot_store.save_path = output.path_join("isolated-run.json")
	await RenderingServer.frame_post_draw
	_capture("title")
	scene.ui.start_requested.emit()
	started = Time.get_ticks_usec()
	RenderingServer.frame_post_draw.connect(_after_draw)
	physics_frame.connect(_input)

func _input() -> void:
	if finishing or not is_instance_valid(scene.player):
		return
	for action in ["move_left", "move_right", "move_up", "move_down", "fire"]:
		Input.action_release(action)
	if scene.run_state != scene.RunState.PLAYING:
		return
	var p: Vector2 = scene.player.global_position
	var threats: Array = []
	var nearest: Node2D
	var distance := INF
	for enemy in scene.wave_director.active_enemies:
		if not is_instance_valid(enemy) or enemy.is_queued_for_deletion() or enemy.health.current_health <= 0:
			continue
		threats.append(enemy.global_position)
		if p.distance_squared_to(enemy.global_position) < distance:
			distance = p.distance_squared_to(enemy.global_position)
			nearest = enemy
	var goal := Vector2(650, 450)
	var navigation: Vector2 = scene.arena_layout.get_navigation_direction(p, goal, scene.player.get_body_radius())
	var direction: Vector2 = pilot.choose_direction(p, navigation, threats, func(point: Vector2) -> bool: return scene.arena_layout.is_position_walkable(point, scene.player.get_body_radius()))
	for pair in [["move_right", maxf(direction.x, 0)], ["move_left", maxf(-direction.x, 0)], ["move_down", maxf(direction.y, 0)], ["move_up", maxf(-direction.y, 0)]]:
		if pair[1] > 0:
			Input.action_press(pair[0], pair[1])
	var mouse := InputEventMouseMotion.new()
	var aim: Vector2 = nearest.global_position if nearest != null else p + Vector2(500, 0)
	mouse.position = root.get_canvas_transform() * aim
	root.push_input(mouse, true)
	Input.action_press("fire")
	samples.append({"physics_frame": Engine.get_physics_frames(), "position": [p.x, p.y], "input": [direction.x, direction.y], "live": threats.size(), "kills": scene.kill_count, "hp": scene.player.health.current_health, "wall": float(Time.get_ticks_usec() - started) / 1000000.0})

func _capture(label: String) -> void:
	var image := root.get_texture().get_image()
	var path := output.path_join(label + ".png")
	var error := image.save_png(path)
	captures.append({"path": path, "error": error, "width": image.get_width(), "height": image.get_height(), "sha256": FileAccess.get_sha256(path), "steps": samples.size()})

func _after_draw() -> void:
	if finishing:
		return
	var second := int(float(Time.get_ticks_usec() - started) / 1000000.0)
	if second in [2, 5, 9] and last_capture != second:
		last_capture = second
		_capture("gameplay-%02d" % second)
	if second >= 10:
		finishing = true
		for action in ["move_left", "move_right", "move_up", "move_down", "fire"]:
			Input.action_release(action)
		var report := {"process_id": OS.get_process_id(), "display": DisplayServer.get_name(), "rendering_method": RenderingServer.get_current_rendering_method(), "inventory": inventory, "outline_exists": ResourceLoader.exists("res://scripts/effects/PlayerOcclusionOutline.gd"), "old_outline_exists": ResourceLoader.exists("res://scripts/art/PlayerOcclusionOutline.gd"), "captures": captures, "samples": samples, "map_seed": scene.map_seed, "state": scene.RunState.keys()[scene.run_state], "pilot_random_heading_changes": pilot.random_heading_changes, "pilot_escape_events": pilot.escape_events, "scope": "Packed Main title and ten-second early gameplay; external input-only policy; not full game, physical audio, frame-rate or art approval."}
		var file := FileAccess.open(output.path_join("native-report.json"), FileAccess.WRITE)
		file.store_string(JSON.stringify(report, "\t"))
		file.close()
		scene.queue_free()
		await process_frame
		await process_frame
		print("STANDALONE_NATIVE_PROBE_COMPLETE")
		quit(0)
