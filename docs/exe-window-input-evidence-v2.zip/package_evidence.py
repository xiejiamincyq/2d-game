"""Archive bounded game pixels/logs, excluding saves, caches and app inventory."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

root = Path(__file__).resolve().parents[4]
run = Path(__file__).resolve().parent
observations = [json.loads(row) for row in (run / "observations/observations.jsonl").read_text(encoding="utf-8").splitlines()]
for row in observations:
    shot = row["screenshot"]
    data = (run / "observations" / shot["filename"]).read_bytes()
    assert len(data) == shot["bytes"] and hashlib.sha256(data).hexdigest() == shot["sha256"]
closed = json.loads((run / "closed.json").read_text(encoding="utf-8"))
assert closed["exit_code"] == 0 and not closed["timed_out"] and not closed["errors"]
assert closed["real_saves_before"] == closed["real_saves_after"]
selected = [run / "launch.json", run / "engine.log", run / "console.log", run / "resume-engine.log",
            run / "observations/observations.jsonl", *[run / "observations" / row["screenshot"]["filename"] for row in observations],
            run / "source/launch_exe_playtest.py", run / "source/exe_window_evidence.mjs", Path(__file__)]
members = {p.relative_to(run).as_posix(): p.read_bytes() for p in selected}
summary = {key: value for key, value in closed.items() if key != "isolated_files"}
summary["scope_note"] = "Derived from original closed.json; cache/save filename inventory omitted; original remains local."
summary["original_errors_field_scope"] = "Original launcher scanned engine.log only, not console.log; errors=[] is not a clean-exit result."
summary["console_forbidden"] = re.findall(r"^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$", (run / "console.log").read_text(encoding="utf-8"), re.M)
summary["clean_exit_gate_passed"] = not summary["console_forbidden"] and not summary["errors"]
summary["resume"] = {"pid": 39816, "exit_code": 0, "scope": "Ordinary Continue click, same EXE/PCK and child APPDATA; first-wave intro boundary only. Exit read directly from retained PowerShell Process; no full-game claim.",
                     "checkpoint_before_sha256_observed": "9930d54c96450ab32234f5dbf32e0df59bac62aa272ca9724adbe000c82f4091",
                     "checkpoint_after_sha256_observed": "6f5ada9f388fd5def80d895988c4a1007006cc4825453e25fe53a3adca1981f4"}
members["closed-summary.json"] = (json.dumps(summary, ensure_ascii=False, indent=2) + "\n").encode()
index = {"scope": "Window input evidence only; no stored profiles, saves or GPU caches. No EXE victory, audio or performance claim.",
         "members": {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in members.items()}}
members["index.json"] = (json.dumps(index, ensure_ascii=False, indent=2) + "\n").encode()
archive = root / "docs/exe-window-input-evidence-v2.zip"
with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED) as output:
    for name, data in members.items():
        output.writestr(name, data)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(members)
    assert all(output.read(name) == data for name, data in members.items())
print(json.dumps({"members": len(members), "observations": len(observations), "bytes": archive.stat().st_size,
                  "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
