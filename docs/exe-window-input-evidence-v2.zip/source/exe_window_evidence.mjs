// Store original game-window pixels for evidence, not for a second inspection.
import { mkdir, writeFile, appendFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';

export async function recordObservation(state, directory, tag) {
  if (!/^[a-z0-9-]{1,64}$/.test(tag) || !state?.window?.app?.includes('five-minute-overdrive.exe')) {
    throw new Error('Refuse non-game observation or unsafe tag');
  }
  const shot = state.screenshots?.[0];
  const match = shot?.url?.match(/^data:image\/(png|jpeg);base64,(.+)$/s);
  if (!match) throw new Error('Expected original bounded game screenshot');
  const bytes = Buffer.from(match[2], 'base64');
  await mkdir(directory, { recursive: true });
  const filename = `${tag}.${match[1] === 'jpeg' ? 'jpg' : 'png'}`;
  await writeFile(path.join(directory, filename), bytes, { flag: 'wx' });
  const row = { tag, observed_epoch_ms: Date.now(), window: state.window,
    screenshot: { id: shot.id, width: shot.width, height: shot.height, filename,
      bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') } };
  await appendFile(path.join(directory, 'observations.jsonl'), `${JSON.stringify(row)}\n`);
  return { tag, filename, sha256: row.screenshot.sha256 };
}
