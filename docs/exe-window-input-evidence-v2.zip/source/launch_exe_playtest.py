"""Launch the retained EXE with process-local isolated AppData, never inject code."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
run = sys.argv[1] if len(sys.argv) == 2 else ""
assert re.fullmatch(r"[A-Za-z0-9_-]{1,64}", run), "Supply a unique safe run id"
output = root / "build/diagnostics/exe-window" / run
output.mkdir(parents=True, exist_ok=False)
profile = output / "appdata"
profile.mkdir()
package = root / "build/playtest/5分钟超载-ranged-v1"
receipt = json.loads((root / "docs/local-playtest-handoff-v4.json").read_text(encoding="utf-8"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else "absent"
for name, expected in receipt["binaries"].items():
    assert digest(package / name) == expected["sha256"] and (package / name).stat().st_size == expected["bytes"]
real_store = Path(os.environ["APPDATA"]) / "Godot/app_userdata/废土清剿协议"
def stores():
    return {name + suffix: digest(real_store / (name + suffix))
            for name in ("five_minute_overdrive_run_v1.json", "five_minute_overdrive_run_test_v1.json")
            for suffix in ("", ".tmp", ".bak")}
before = stores()
environment = os.environ.copy()
environment["APPDATA"] = str(profile)
argv = [str(package / "five-minute-overdrive.exe"), "--audio-driver", "Dummy", "--resolution", "1280x720", "--log-file", str(output / "engine.log")]
started = time.time()
with (output / "console.log").open("x", encoding="utf-8") as stream:
    process = subprocess.Popen(argv, cwd=package, env=environment, stdout=stream, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    start = {"scope": "actual retained release EXE normal Main and ordinary window input; only child APPDATA/log/audio-driver differ; no --script/--path/cheats or modified PCK",
             "pid": process.pid, "argv": argv, "cwd": str(package), "child_appdata": str(profile), "started_epoch": started,
             "binaries": receipt["binaries"], "real_saves_before": before}
    (output / "launch.json").write_text(json.dumps(start, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"pid": process.pid, "run": run, "child_appdata": str(profile)}, ensure_ascii=False), flush=True)
    timed_out = False
    try:
        code = process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        code = process.wait(timeout=5)
text = (output / "engine.log").read_text(encoding="utf-8") if (output / "engine.log").exists() else ""
result = dict(start, exit_code=code, timed_out=timed_out, wall_seconds=time.time()-started,
              real_saves_after=stores(), errors=re.findall(r"^.*(?:SCRIPT ERROR|ERROR:|ObjectDB instances were leaked|RID.+leaked|resources still in use).*$", text, re.M),
              isolated_files=[p.relative_to(profile).as_posix() for p in profile.rglob("*") if p.is_file()])
(output / "closed.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"pid": process.pid, "exit_code": code, "timed_out": timed_out, "real_saves_unchanged": stores() == before, "errors": result["errors"]}, ensure_ascii=False), flush=True)
raise SystemExit(0 if code == 0 and not timed_out and not result["errors"] and stores() == before else 2)
